package com.example.admin.revatureapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;


public class MyActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    String title[] = new String[100];
    String description[] = new String[100];
    String imageUrl[] = new String[100];
    String quizId[] = new String[100];
    String quizAttempts[] = new String[100];
    String status[] = new String[100];
    String categoryName[] = new String[100];
    String activityPoint[] = new String[100];
    EditText search;
    Login login;
    String token;
    String result;
    RecyclerView recyclerView, horirecyclerView;
    InputStream inputStream = null;
    ArrayList<MyActivityModel> myactivity = new ArrayList();
    ArrayList<String> category = new ArrayList();
    DataAdapter adapter = new DataAdapter();
    int length;
    JSONObject json;
    TextView profileName, emailId;
    ImageView profileImage;
    DrawerLayout drawer;
    NavigationView navigationView;
    String email, profile_Name;
Context context;
    public static String[] removeDuplicateElements(String[] categoryName, int n) {

        String[] temp = new String[n];
        int j = 0;
        for (int i = 0; i < n - 1; i++) {
            if (categoryName[i] != categoryName[i + 1]) {
                temp[j++] = categoryName[i];
            }
        }
        temp[j++] = categoryName[n - 1];
        // Changing original array
        for (int i = 0; i < j; i++) {
            categoryName[i] = temp[i];
        }
        return categoryName;
    }

    private static String convertInputStreamToString(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String line = "";
        StringBuilder result = new StringBuilder();
        while ((line = bufferedReader.readLine()) != null)
            result.append(line);

        inputStream.close();
        System.out.println("InputStream:" + result.toString());

        return result.toString();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_myactivity);
        context=getApplicationContext();
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        myToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawer.openDrawer(Gravity.LEFT);
            }
        });
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        profileName = (TextView) navigationView.getHeaderView(0).findViewById(R.id.profileName);
        profileImage = (ImageView) navigationView.getHeaderView(0).findViewById(R.id.profileImage);
        emailId = (TextView) navigationView.getHeaderView(0).findViewById(R.id.emailId);

        navigationView.setNavigationItemSelectedListener(this);
        search = (EditText) findViewById(R.id.search_box);
        login = (Login) getIntent().getSerializableExtra("Login");
        try {
            String json1=DashboardActivity.getDefaults("json",context);
            json = new JSONObject(json1);
            System.out.println(json.toString());
            JSONObject array = json;
            email = array.getString("email");
            profile_Name = array.getString("fullName");
        } catch (Exception e) {
            e.printStackTrace();
        }
        new Image().execute();

        profileName.setText(profile_Name);
        initViews();

        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                System.out.println("Char:" + charSequence.toString());

                filter(charSequence.toString());

            }

            @Override
            public void afterTextChanged(Editable editable) {
                //after the change calling the method and passing the search input
            }
        });


    }

    private void filter(String text) {
        //new array list that will hold the filtered data
        ArrayList<MyActivityModel> filterdNames = new ArrayList<>();

        //looping through existing elements
        for (MyActivityModel s : myactivity) {
            //if the existing elements contains the search input
            if (s.getTitle().toLowerCase().contains(text.toLowerCase())) {
                //adding the element to filtered list
                filterdNames.add(s);
            }
        }
        System.out.println("Filtered" + filterdNames);

        //calling a method of the adapter class and passing the filtered list
        adapter = new DataAdapter(getApplicationContext(), filterdNames, login, json);
        recyclerView.setAdapter(adapter);
    }

    private void initViews() {
        horirecyclerView = (RecyclerView) findViewById(R.id.horizontalrecyclerView);
        // set a LinearLayoutManager with default horizontal orientation and false value for reverseLayout to show the items from start to end
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(getApplicationContext(), LinearLayoutManager.HORIZONTAL, false);
        horirecyclerView.setLayoutManager(linearLayoutManager);
        // call the constructor of CustomAdapter to send the reference and data to Adapter
        CustomAdapter customAdapter = new CustomAdapter(MyActivity.this, myactivity, recyclerView,login,json);
        horirecyclerView.setAdapter(customAdapter);
        recyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getApplicationContext());
        recyclerView.setLayoutManager(layoutManager);
        new Myquizzes().execute();
        System.out.println(myactivity);
        DataAdapter adapter = new DataAdapter(getApplicationContext(), myactivity, login, json);
        recyclerView.setAdapter(adapter);

    }

    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.dashboard) {
            Intent intent = new Intent(this, DashboardActivity.class);
            intent.putExtra("Login_Class", login);
            intent.putExtra("JSON_RESPONSE", json.toString());
            startActivity(intent);
        } else if (id == R.id.quizzes) {
            Intent intent = new Intent(this, MyActivity.class);
            intent.putExtra("Login", login);
            intent.putExtra("JSON_RESPONSE", json.toString());

            startActivity(intent);
        } else if (id == R.id.profile) {
            Intent intent = new Intent(this, Profile.class);
            intent.putExtra("Login_object", login);

            intent.putExtra("Json_obj", json.toString());

            startActivity(intent);
        } else if (id == R.id.logout) {
            new android.app.AlertDialog.Builder(this).setIcon(android.R.drawable.ic_dialog_alert).setTitle("Logout")
                    .setMessage("Are you sure?")
                    .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            new Logout().execute();
                        }
                    }).setNegativeButton("no", null).show();

        }

        item.setChecked(true);
        // close drawer when item is tapped
        drawer.closeDrawers();
        return true;
    }

    public ArrayList prepareData() {
        System.out.println(Arrays.toString(title));
        ArrayList myactivity = new ArrayList<>();
        for (int i = 0; i < length; i++) {

            MyActivityModel myActivityModel = new MyActivityModel();
            myActivityModel.setTitle(title[i]);
            myActivityModel.setDescription(description[i]);
            myActivityModel.setImageUrl(imageUrl[i]);
            myActivityModel.setQuizId(quizId[i]);
            myActivityModel.setStatus(status[i]);
            myActivityModel.setCategory(categoryName[i]);
            if (i < category.size()) {
                myActivityModel.setCategoryName(category.get(i));
            }
            myActivityModel.setActivityPoint(activityPoint[i]);
            myactivity.add(myActivityModel);
            System.out.println(myactivity);
        }

        return myactivity;

    }

    public void search() {
        if (!myactivity.isEmpty()) {
            search.setVisibility(View.VISIBLE);
        } else {
            search.setVisibility(View.INVISIBLE);
        }
    }

    class Image extends AsyncTask<String, String, String> {
        InputStream inputStream = null;
        String result;

        @Override
        protected void onPostExecute(String s) {
            try {
                JSONObject myObject = new JSONObject(result);
                String statusCode = myObject.getString("statusCode");
                String image = myObject.getString("data");
                new DownLoadImageTask(profileImage).execute(image);


            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                HttpGet get = new HttpGet("https://qa2.revature.com/core/resources/secure/interns/image");
                get.setHeader("Authorization", login.getToken());
                get.setHeader("Accept", "application/json");
                HttpClient client = new DefaultHttpClient();
                HttpResponse response = client.execute(get);
                inputStream = response.getEntity().getContent();
                if (inputStream != null) {
                    result = convertInputStreamToString(inputStream);
                } else
                    result = "Did not work!";
                return null;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    private class DownLoadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView imageView;

        public DownLoadImageTask(ImageView imageView) {
            this.imageView = imageView;
        }

        /*
            doInBackground(Params... params)
                Override this method to perform a computation on a background thread.
         */
        protected Bitmap doInBackground(String... urls) {
            String urlOfImage = urls[0];
            Bitmap logo = null;
            try {
                InputStream is = new URL(urlOfImage).openStream();
                /*
                    decodeStream(InputStream is)
                        Decode an input stream into a bitmap.
                 */
                logo = BitmapFactory.decodeStream(is);
            } catch (Exception e) { // Catch the download exception
                e.printStackTrace();
            }
            return logo;
        }

        /*
            onPostExecute(Result result)
                Runs on the UI thread after doInBackground(Params...).
         */
        protected void onPostExecute(Bitmap result) {
            imageView.setImageBitmap(result);
        }
    }

    class Logout extends AsyncTask<String, String, String> {
        ProgressDialog progress;

        @Override
        protected void onPreExecute() {
            progress = new ProgressDialog(MyActivity.this);
            progress.setMessage("Processing your logout request");
            progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progress.setIndeterminate(true);
            progress.show();
        }

        @Override
        protected void onPostExecute(String s) {
            try {
                JSONObject json = new JSONObject(result);
                progress.cancel();
                String statusCode = json.getString("statusCode");
                if (statusCode.equals("SC007")) {
                    Toast.makeText(getBaseContext(), "Logged out successfully ", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(MyActivity.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(String... strings) {
            try {
                HttpPost post = new HttpPost("https://qa2.revature.com/core/resources/secure/interns/logout");
                post.setHeader("Accept", "application/json");
                post.setHeader("Authorization", login.getToken());
                HttpClient httpclient = new DefaultHttpClient();
                HttpResponse res = httpclient.execute(post);

                inputStream = res.getEntity().getContent();


                if (inputStream != null) {
                    result = convertInputStreamToString(inputStream);
                } else {
                    result = "Did not work!";
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }

    class Myquizzes extends AsyncTask<String, String, String> {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected String doInBackground(String... strings) {
            token = login.getToken();

            try {
                HttpGet get = new HttpGet("https://qa2.revature.com/core/resources/secure/quizzes/1");
                get.setHeader("Accept", "application/json");
                get.setHeader("Authorization", token);
                HttpClient httpclient = new DefaultHttpClient();
                HttpResponse res = httpclient.execute(get);

                inputStream = res.getEntity().getContent();


                if (inputStream != null) {
                    result = convertInputStreamToString(inputStream);
                } else {
                    result = "Did not work!";
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {

            int len = 0;

            try {
                JSONObject json1 = new JSONObject(result);
                JSONArray array = json1.getJSONArray("data");
                length = array.length();
                System.out.println(length);

                if (array != null) {
                    len = array.length();

                    for (int i = 0; i < len; i++) {
                        JSONObject obj = array.getJSONObject(i);

                        title[i] = obj.get("title").toString();
                        if (obj.has("description")) {
                            description[i] = obj.get("description").toString();

                        }
                        imageUrl[i] = obj.get("imageUrl").toString();
                        quizId[i] = obj.get("id").toString();
                        categoryName[i] = obj.get("categoryName").toString();

                        category.add(obj.get("categoryName").toString());


                        if (obj.has("quizStatusCode")) {
                            if (obj.get("quizStatusCode").toString().equals("ST011")) {
                                status[i] = "In-Progress";
                                int remainingattempts = 0;
                                int internAttempts = Integer.parseInt(obj.get("internAttempts").toString());
                                int qAttempt = Integer.parseInt(obj.get("quizAttempts").toString());
                                remainingattempts = qAttempt - internAttempts;
                                quizAttempts[i] = Integer.toString(remainingattempts);


                            } else if (obj.get("quizStatusCode").toString().equals("ST012")) {

                                int remainingattempts = 0;
                                int internAttempts = Integer.parseInt(obj.get("internAttempts").toString());
                                int qAttempt = Integer.parseInt(obj.get("quizAttempts").toString());
                                remainingattempts = qAttempt - internAttempts;
                                quizAttempts[i] = Integer.toString(remainingattempts);
                                if (remainingattempts == 0)
                                    status[i] = "Locked";
                                else
                                    status[i] = "Re-Take";

                            }

                        } else {
                            status[i] = "Details";

                        }
                    }

                }

                for (int i1 = 0; i1 < category.size(); i1++) {

                    for (int j = i1 + 1; j < category.size(); j++) {
                        if (category.get(i1).equals(category.get(j))) {
                            category.remove(j);
                            j--;
                        }
                    }

                }
                myactivity = prepareData();


                CustomAdapter customAdapter = new CustomAdapter(getApplicationContext(), myactivity, recyclerView,login, json);
                horirecyclerView.setAdapter(customAdapter);
                DataAdapter adapter = new DataAdapter(getApplicationContext(), myactivity, login, json);

                recyclerView.setAdapter(adapter);
                search();

            } catch (Exception e) {
                e.printStackTrace();
            }

        }


    }
}
