package com.example.admin.revatureapp;

import android.content.Context;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.json.JSONObject;

public class SaveActivity extends AppCompatActivity {

    Button button;
    TextView text;
Login login;
JSONObject json;
Toolbar quizTitle;
Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save);
        context=getApplicationContext();
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        String title=getIntent().getStringExtra("title");
        quizTitle=(Toolbar)findViewById(R.id.toolbar);
        quizTitle.setTitle(title);
        login = (Login) getIntent().getSerializableExtra("Login");


        System.out.println("Log"+login);
     try {
         String json1=DashboardActivity.getDefaults("json",context);
         json = new JSONObject(json1);
         System.out.println(json.toString());
         JSONObject array = json;     }catch(Exception e)
     {
         e.printStackTrace();
     }
        button=(Button)findViewById(R.id.goBack);
     text=(TextView)findViewById(R.id.quizzes);
     text.setOnClickListener(new View.OnClickListener() {
         @Override
         public void onClick(View v) {
             Intent intent = new Intent(SaveActivity.this,MyActivity.class);
             intent.putExtra("Login",login);
             intent.putExtra("JSON_RESPONSE",json.toString());
             startActivity(intent);
         }
     });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SaveActivity.this,DashboardActivity.class);
                intent.putExtra("Login_Class",login);
                intent.putExtra("JSON_RESPONSE",json.toString());
                startActivity(intent);
            }
        });

    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(SaveActivity.this,DashboardActivity.class);
        intent.putExtra("Login_Class",login);
        intent.putExtra("JSON_RESPONSE",json.toString());
        startActivity(intent);
    }
}
