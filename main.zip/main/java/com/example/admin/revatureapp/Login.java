package com.example.admin.revatureapp;

import java.io.Serializable;
import java.util.Arrays;

/**
 * Created by admin on 1/24/2018.
 */

public class Login implements Serializable{

    private String username;
    private String password;
    private String timeZone;
    private String token;
    private byte[] encodedtoken;

    public byte[] getEncodedtoken() {
        return encodedtoken;
    }

    public void setEncodedtoken(byte[] encodedtoken) {
        this.encodedtoken = encodedtoken;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public String getToken() {
        return token;
    }


    public void setToken(String token) {
        this.token = token;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "Login{" +
                "username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", timeZone='" + timeZone + '\'' +
                ", token='" + token + '\'' +
                ", encodedtoken=" + Arrays.toString(encodedtoken) +
                '}';
    }
}
