package com.example.admin.revatureapp;


import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.TimeZone;

public class Change_Password extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
    Button button;
    EditText currentPwd,newPwd,confirmPwd;
    ImageView imageview1,imageview2,imageview3;
    InputStream inputStream=null;
    String token,result;
    ImageView profileImage;

    DrawerLayout drawer;
    NavigationView navigationView;
    TextView emailid,name;
    String current_pwd,email,profile_Name;
    Login login;
    String new_pwd;
JSONObject json;
Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change__password);
        context=getApplicationContext();
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
myToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawer.openDrawer(Gravity.LEFT);
            }
        });
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        name = (TextView) navigationView.getHeaderView(0).findViewById(R.id.profileName);
        emailid = (TextView) navigationView.getHeaderView(0).findViewById(R.id.emailId);
        profileImage = (ImageView) navigationView.getHeaderView(0).findViewById(R.id.profileImage);

        navigationView.setNavigationItemSelectedListener(this);
      login  = (Login)getIntent().getSerializableExtra("Log_object");
        new Image().execute();

        button= (Button) findViewById(R.id.ok_button);
        currentPwd=(EditText)findViewById(R.id.current_password);
        newPwd=(EditText)findViewById(R.id.new_password);
        imageview1=(ImageView)findViewById(R.id.imageButton1);
        imageview2=(ImageView)findViewById(R.id.imageButton2);
        imageview3=(ImageView)findViewById(R.id.imageButton3);
      //  confirmPwd=(EditText)findViewById(R.id.confirm_password);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                 if (currentPwd.getText().length() == 0) {
                    currentPwd.setError("CurrentPassword cannot be blank ");
                } else if (newPwd.getText().length() == 0) {
                    newPwd.setError("NewPassword cannot be blank");
                }
                else if (newPwd.getText().toString().equals(currentPwd.getText().toString())) {
                     newPwd.setError("Current Password and New password should not be same");
                 }
                else {
                    new ChangePassword().execute();
                }



            }
        });
try
{
    String json1=DashboardActivity.getDefaults("json",context);
    json = new JSONObject(json1);
    System.out.println(json.toString());
    JSONObject array = json;

            email=array.getString("email");
            profile_Name=array.getString("fullName");

}catch(Exception e)
{
    e.printStackTrace();
}

        name.setText(profile_Name);
        imageview2.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Change_Password.this, Education_Details.class);
                intent.putExtra("JSON",json.toString());
                intent.putExtra("log",login);

                startActivity(intent);

            }

        });imageview1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Change_Password.this, Profile.class);
                intent.putExtra("Json_obj",json.toString());
                intent.putExtra("Login_object",login);
                startActivity(intent);

            }

        });
    }

    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.dashboard) {
            Intent intent = new Intent(this,DashboardActivity.class);
            intent.putExtra("Login_Class",login);
            intent.putExtra("JSON_RESPONSE",json.toString());
            startActivity(intent);
        } else if (id == R.id.quizzes) {
            Intent intent = new Intent(this,MyActivity.class);
            intent.putExtra("Login",login);
            intent.putExtra("JSON_RESPONSE",json.toString());

            startActivity(intent);
        }else if (id == R.id.profile){
            Intent intent = new Intent(this,Profile.class);
            intent.putExtra("Login_object",login);

            intent.putExtra("Json_obj",json.toString());

            startActivity(intent);
        }else if (id == R.id.logout){
            new android.app.AlertDialog.Builder(this).setIcon(android.R.drawable.ic_dialog_alert).setTitle("Signout")
                    .setMessage("Are you sure?")
                    .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            new Logout().execute();

                        }
                    }).setNegativeButton("no", null).show();

        }

        item.setChecked(true);
        // close drawer when item is tapped
        drawer.closeDrawers();
        return true;
    }

    class Logout extends AsyncTask<String,String,String>
    {
        ProgressDialog progress;
        @Override
        protected void onPreExecute() {
            progress=new ProgressDialog(Change_Password.this);
            progress.setMessage("Processing your change password request");
            progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progress.setIndeterminate(true);
            progress.show();        }

        @Override
        protected void onPostExecute(String s) {
            try
            {
                JSONObject json = new JSONObject(result);
                progress.cancel();
                String statusCode=json.getString("statusCode");
                System.out.println("status"+statusCode);
                if(statusCode.equals("SC007"))
                {
                    Toast.makeText(getBaseContext(), "Logged out successfully ", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(Change_Password.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }
            }catch(Exception e)
            {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(String... strings) {
            try{
                HttpPost post = new HttpPost("https://qa2.revature.com/core/resources/secure/interns/logout");
                post.setHeader("Accept","application/json");
                post.setHeader("Authorization",login.getToken());
                HttpClient httpclient = new DefaultHttpClient();
                HttpResponse res = httpclient.execute(post);

                inputStream = res.getEntity().getContent();


                if (inputStream != null) {
                    result = convertInputStreamToString(inputStream);
                } else {
                    result = "Did not work!";
                }

            }catch(Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }
    }
    class Image extends AsyncTask<String,String,String>
    {
        InputStream inputStream=null;
        String result;
        @Override
        protected void onPostExecute(String s) {
            try
            {
                JSONObject myObject = new JSONObject(result);
                String statusCode = myObject.getString("statusCode");
                String image=myObject.getString("data");
                new DownLoadImageTask(profileImage).execute(image);



            }catch(Exception e)
            {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(String... strings) {
            try
            {
                HttpGet get= new HttpGet("https://qa2.revature.com/core/resources/secure/interns/image");
                get.setHeader("Authorization",login.getToken());
                get.setHeader("Accept","application/json");
                HttpClient client = new DefaultHttpClient();
                HttpResponse response = client.execute(get);
                inputStream = response.getEntity().getContent();
                if (inputStream != null){
                    result = convertInputStreamToString(inputStream);
                }
                else
                    result = "Did not work!";
                return null;
            }catch (Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }
    }
    private class DownLoadImageTask extends AsyncTask<String,Void,Bitmap>{
        ImageView imageView;

        public DownLoadImageTask(ImageView imageView){
            this.imageView = imageView;
        }

        /*
            doInBackground(Params... params)
                Override this method to perform a computation on a background thread.
         */
        protected Bitmap doInBackground(String...urls){
            String urlOfImage = urls[0];
            Bitmap logo = null;
            try{
                InputStream is = new URL(urlOfImage).openStream();
                /*
                    decodeStream(InputStream is)
                        Decode an input stream into a bitmap.
                 */
                logo = BitmapFactory.decodeStream(is);
            }catch(Exception e){ // Catch the download exception
                e.printStackTrace();
            }
            return logo;
        }

        /*
            onPostExecute(Result result)
                Runs on the UI thread after doInBackground(Params...).
         */
        protected void onPostExecute(Bitmap result){
            imageView.setImageBitmap(result);
        }
    }
    class ChangePassword extends AsyncTask<String,String,String> {

       // String confirm_pwd=confirmPwd.getText().toString();
        String result;
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            try{
                JSONObject myObject = new JSONObject(result);
                String statusCode = myObject.getString("statusCode");
                String description=myObject.getString("description");
                if(statusCode.equals("SC007")){
                    Toast.makeText(getBaseContext(),description +" "+"You will be redirected to  login" , Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(Change_Password.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(getBaseContext(), description, Toast.LENGTH_LONG).show();

                }}catch(Exception e){
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(String... strings) {
            token = login.getToken();
            byte[] token1=login.getEncodedtoken();
            System.out.println(token);
            current_pwd=currentPwd.getText().toString();
            System.out.println(current_pwd);
            new_pwd=newPwd.getText().toString();
            try{
                HttpClient client = new DefaultHttpClient();
                HttpPut post = new HttpPut("https://qa2.revature.com/core/resources/secure/interns/changepassword");
                post.setHeader("Accept","application/json");
                post.setHeader("Content-type","application/json");
                post.setHeader("Authorization",token);
                System.out.println(token);

                byte[] decodedtoken= Base64.decodeBase64(token1);
                String dectoken= new String(decodedtoken);
                System.out.println(dectoken);
                JSONObject json = new JSONObject();
                json.accumulate("token",dectoken);
                json.accumulate("oldPassword",current_pwd);
                json.accumulate("newPassword",new_pwd);
                json.accumulate("endSession","true");
                String jsonString= json.toString();
                byte[] encodedPostData = Base64.encodeBase64(jsonString.getBytes(Charset.forName("UTF-8")));
                String userData= new String(encodedPostData);
                StringEntity entity = new StringEntity(userData);
                System.out.println("data"+userData);
                post.setEntity(entity);

                HttpResponse response = client.execute(post);

                inputStream= response.getEntity().getContent();


                if (inputStream != null){
                    result = convertInputStreamToString(inputStream);
                }
                else
                    result = "Did not work!";
                return null;

            }catch(Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }

    }


    private static String convertInputStreamToString(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String line = "";
        StringBuilder result = new StringBuilder();
        while ((line = bufferedReader.readLine()) != null)
            result.append(line);

        inputStream.close();
        System.out.println("InputStream:" + result.toString());

        return result.toString();

    }

}
