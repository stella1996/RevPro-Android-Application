package com.example.admin.revatureapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;

public class SubmitActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {
String per,passPer;TextView text,result;ImageView imageview;Button button;Login login;JSONObject json;
    TextView profileName,emailId;
    ImageView profileImage;
    DrawerLayout drawer;
    Toolbar quizTitle;
    NavigationView navigationView;
    String email,profile_Name,result1;
    InputStream inputStream;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_submit);
        context=getApplicationContext();
        per=getIntent().getStringExtra("per");
        passPer=getIntent().getStringExtra("passper");
        float percentage=Float.parseFloat(per);
        text=(TextView)findViewById(R.id.percentage);
        imageview=(ImageView)findViewById(R.id.percentage1);
        button=(Button)findViewById(R.id.goBack);
        result=(TextView)findViewById(R.id.result);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        String title=getIntent().getStringExtra("title");
        quizTitle=(Toolbar)findViewById(R.id.toolbar);

        quizTitle.setTitle(title);
        myToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawer.openDrawer(Gravity.LEFT);
            }
        });
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        navigationView = (NavigationView) findViewById(R.id.nav_view);
        profileName = (TextView) navigationView.getHeaderView(0).findViewById(R.id.profileName);
        profileImage = (ImageView) navigationView.getHeaderView(0).findViewById(R.id.profileImage);
        emailId = (TextView) navigationView.getHeaderView(0).findViewById(R.id.emailId);

        navigationView.setNavigationItemSelectedListener(this);
        login = (Login) getIntent().getSerializableExtra("Login");
        System.out.println("Log"+login);
        try {
            String json1=DashboardActivity.getDefaults("json",context);
            json = new JSONObject(json1);
            System.out.println(json.toString());
            JSONObject array = json;
            System.out.println("loginjson"+json.toString());
            email=array.getString("email");
            profile_Name=array.getString("fullName");
        }catch(Exception e)
        {
            e.printStackTrace();
        }
        text.setText(Math.abs(percentage)+"%");
        profileName.setText(profile_Name);
        if(passPer.equals("Y"))
        {
            imageview.setBackgroundResource(R.drawable.ic_success);
            imageview.setMaxWidth(300);
            imageview.setMaxHeight(300);
            result.setTextColor(getResources().getColor(R.color.success));
            result.setText("YOU PASSED SUCCESSFULLY!!!");
        }
        else{
            imageview.setBackgroundResource(R.drawable.ic_failure);
            result.setTextColor(getResources().getColor(R.color.failure));
            result.setText("We're sorry but you did not pass the quiz in this attempt.");

        }
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(SubmitActivity.this,DashboardActivity.class);
                intent.putExtra("Login_Class",login);
                intent.putExtra("JSON_RESPONSE",json.toString());
                startActivity(intent);
            }
        });

    }
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.dashboard) {
            Intent intent = new Intent(this,DashboardActivity.class);
            intent.putExtra("Login_Class",login);
            intent.putExtra("JSON_RESPONSE",json.toString());
            startActivity(intent);
        } else if (id == R.id.quizzes) {
            Intent intent = new Intent(this,MyActivity.class);
            intent.putExtra("Login",login);
            intent.putExtra("JSON_RESPONSE",json.toString());

            startActivity(intent);
        }else if (id == R.id.profile){
            Intent intent = new Intent(this,Profile.class);
            intent.putExtra("Login_object",login);

            intent.putExtra("Json_obj",json.toString());

            startActivity(intent);
        }else if (id == R.id.logout){
            new android.app.AlertDialog.Builder(this).setIcon(android.R.drawable.ic_dialog_alert).setTitle("Signout")
                    .setMessage("Are you sure?")
                    .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            new Logout().execute();
                        }
                    }).setNegativeButton("no", null).show();

        }

        item.setChecked(true);
        // close drawer when item is tapped
        drawer.closeDrawers();
        return true;
    }
    class Logout extends AsyncTask<String,String,String>
    {
        ProgressDialog progress;
        @Override
        protected void onPreExecute() {
            progress=new ProgressDialog(SubmitActivity.this);
            progress.setMessage("Processing your logout request");
            progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progress.setIndeterminate(true);
            progress.show();        }

        @Override
        protected void onPostExecute(String s) {
            try
            {
                JSONObject json = new JSONObject(result1);
                progress.cancel();
                String statusCode=json.getString("statusCode");
                if(statusCode.equals("SC007"))
                {
                    Toast.makeText(getBaseContext(), "Logged out successfully ", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(SubmitActivity.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }
            }catch(Exception e)
            {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(String... strings) {
            try{
                HttpPost post = new HttpPost("https://qa2.revature.com/core/resources/secure/interns/logout");
                post.setHeader("Accept","application/json");
                post.setHeader("Authorization",login.getToken());
                HttpClient httpclient = new DefaultHttpClient();
                HttpResponse res = httpclient.execute(post);

                inputStream = res.getEntity().getContent();


                if (inputStream != null) {
                    result1 = convertInputStreamToString(inputStream);
                } else {
                    result1 = "Did not work!";
                }

            }catch(Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }
    }
    class Image extends AsyncTask<String,String,String>
    {
        InputStream inputStream=null;
        String result;
        @Override
        protected void onPostExecute(String s) {
            try
            {
                JSONObject myObject = new JSONObject(result);
                String statusCode = myObject.getString("statusCode");
                String image=myObject.getString("data");
                new DownLoadImageTask(profileImage).execute(image);



            }catch(Exception e)
            {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(String... strings) {
            try
            {
                HttpGet get= new HttpGet("https://qa2.revature.com/core/resources/secure/interns/image");
                get.setHeader("Authorization",login.getToken());
                get.setHeader("Accept","application/json");
                HttpClient client = new DefaultHttpClient();
                HttpResponse response = client.execute(get);
                inputStream = response.getEntity().getContent();
                if (inputStream != null){
                    result = convertInputStreamToString(inputStream);
                }
                else
                    result = "Did not work!";
                return null;
            }catch (Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }
    }
    private static String convertInputStreamToString(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String line = "";
        StringBuilder result = new StringBuilder();
        while ((line = bufferedReader.readLine()) != null)
            result.append(line);

        inputStream.close();
        System.out.println("InputStream:" + result.toString());

        return result.toString();
    }
    private class DownLoadImageTask extends AsyncTask<String,Void,Bitmap>{
        ImageView imageView;

        public DownLoadImageTask(ImageView imageView){
            this.imageView = imageView;
        }

        /*
            doInBackground(Params... params)
                Override this method to perform a computation on a background thread.
         */
        protected Bitmap doInBackground(String...urls){
            String urlOfImage = urls[0];
            Bitmap logo = null;
            try{
                InputStream is = new URL(urlOfImage).openStream();
                /*
                    decodeStream(InputStream is)
                        Decode an input stream into a bitmap.
                 */
                logo = BitmapFactory.decodeStream(is);
            }catch(Exception e){ // Catch the download exception
                e.printStackTrace();
            }
            return logo;
        }

        /*
            onPostExecute(Result result)
                Runs on the UI thread after doInBackground(Params...).
         */
        protected void onPostExecute(Bitmap result){
            imageView.setImageBitmap(result);
        }
    }

    @Override
    public void onBackPressed() {
        Intent intent = new Intent(SubmitActivity.this,DashboardActivity.class);
        intent.putExtra("Login_Class",login);
        intent.putExtra("JSON_RESPONSE",json.toString());
        startActivity(intent);    }
}

