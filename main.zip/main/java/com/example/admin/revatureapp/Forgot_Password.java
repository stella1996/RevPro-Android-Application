package com.example.admin.revatureapp;

import android.app.Activity;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import org.apache.commons.codec.binary.Base64;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;


/**
 * Created by admin on 1/10/2018.
 */

public class Forgot_Password extends AppCompatActivity {
    InputStream inputStream=null;
EditText editText;
Button reset_button;
String email;
String result;

        @Override
        public void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.forgot_password);
            Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
            setSupportActionBar(myToolbar);
            editText=(EditText)findViewById(R.id.editText);
            reset_button=(Button)findViewById(R.id.reset_button);
            reset_button.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if(editText.getText().length()==0)
                    {
                        editText.setError("Email is required");
                    }
                    else {
                        new resetpwd().execute();
                    }
                }
            });

        }


class resetpwd extends AsyncTask<String,String,String>
{


    @Override
    protected void onPreExecute() {
        super.onPreExecute();
    }

    @Override
    protected void onPostExecute(String s) {
        try{
            JSONObject myObject = new JSONObject(result);
            String statusCode = myObject.getString("statusCode");
            String description=myObject.getString("description");
            if(statusCode.equals("SC005")){


                Toast.makeText(getBaseContext(),"We've sent you an email with instructions to reset your password" , Toast.LENGTH_LONG).show();
                  Intent intent = new Intent(Forgot_Password.this,MainActivity.class);
                  startActivity(intent);

            }
            else
            {
                Toast.makeText(getBaseContext(), description, Toast.LENGTH_LONG).show();

            }}catch(Exception e){
            System.out.println(e);
        }
    }

    @Override
    protected String doInBackground(String... strings) {
        email=editText.getText().toString();
            try{
                HttpPost post = new HttpPost("https://qa2.revature.com/core/resources/interns/forgotPassword");
                post.setHeader("Accept","application/json");
                post.setHeader("Content-type","application/json");
                byte[] encodedEmail= Base64.encodeBase64(email.getBytes(Charset.forName("UTF-8")));
                String stringEmail= new String(encodedEmail);
                JSONObject json = new JSONObject();
                json.accumulate("email",stringEmail);
                String jsonString= json.toString();
                byte[] encodedPostData = Base64.encodeBase64(jsonString.getBytes(Charset.forName("UTF-8")));
                String userData= new String(encodedPostData);
                System.out.println(userData.toString());
                StringEntity entity = new StringEntity(userData);
                post.setEntity(entity);
                HttpClient client = new DefaultHttpClient();
                HttpResponse response = client.execute(post);
                inputStream= response.getEntity().getContent();
                if (inputStream != null){
                    result = convertInputStreamToString(inputStream);
                }
                else
                    result = "Did not work!";
                return null;

            }catch(Exception e)
            {
                System.out.println(e);
            }
            return null;
    }
}



    private static String convertInputStreamToString(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while ((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();
        System.out.println("InputStream:" + result);

        return result;

    }

}
