package com.example.admin.revatureapp;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

/**
 * Created by home on 3/5/2018.
 */

public class DataAdapter extends RecyclerView.Adapter<DataAdapter.ViewHolder> {
String id,token,result;
private Login login;
    String url;
InputStream inputStream;
    private ArrayList<MyActivityModel> myactivitytmodel;
    private Context context;
    public boolean isClickable;
    JSONObject json;
public DataAdapter(ArrayList<MyActivityModel> myactivitytmodel,Login login,JSONObject json)
{
    this.myactivitytmodel=myactivitytmodel;
    this.json=json;
    this.login=login;
}
    public DataAdapter()
    {

    }
    public DataAdapter(Context context, ArrayList<MyActivityModel> myactivitytmodel, Login login, JSONObject json) {
        this.context=context;
        this.myactivitytmodel=myactivitytmodel;
        this.login=login;
        this.json=json;
    }



    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.rowlayout, parent, false);
        // set the view's size, margins, paddings and layout parameters
        ViewHolder vh = new ViewHolder(v); // pass the view to View Holder
        return vh;    }

    @Override
    public void onBindViewHolder(ViewHolder holder,final int position) {

        holder.title.setText(myactivitytmodel.get(position).getTitle());
        holder.status.setText(myactivitytmodel.get(position).getStatus());

            if (myactivitytmodel.get(position).getStatus().equals("In-Progress")) {
                holder.status.setVisibility(View.VISIBLE);
                holder.status.setBackgroundResource(R.color.inProgress);
            }
            else if (myactivitytmodel.get(position).getStatus().equals("Re-Take")) {
                holder.status.setVisibility(View.VISIBLE);
                holder.status.setBackgroundResource(R.color.reTake);
            }
            else if(myactivitytmodel.get(position).getStatus().equals("Locked")){
                holder.status.setVisibility(View.VISIBLE);
                holder.status.setBackgroundResource(R.color.locked);
            }
            else {
            holder.status.setBackgroundResource(R.color.colorPrimaryDark);
        }


        holder.description.setText(myactivitytmodel.get(position).getDescription());
        Picasso.with(context).load(myactivitytmodel.get(position).getImageUrl()).resize(120,60).into(holder.image);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                    if (myactivitytmodel.get(position).getStatus().equals("In-Progress")) {
                        Intent intent = new Intent(context, QuizDetails.class);
                        intent.putExtra("Log", login);
                        intent.putExtra("Id", myactivitytmodel.get(position).getQuizId());
                        intent.putExtra("ImageUrl", myactivitytmodel.get(position).getImageUrl());
                        intent.putExtra("Title", myactivitytmodel.get(position).getTitle());
                        intent.putExtra("Description", myactivitytmodel.get(position).getDescription());
                        intent.putExtra("QuizStatus", myactivitytmodel.get(position).getStatus());
                        intent.putExtra("json",json.toString());
                        context.startActivity(intent);
                    } else if (myactivitytmodel.get(position).getStatus().equals("Re-Take")) {
                        Intent intent = new Intent(context, QuizDetails.class);
                        intent.putExtra("Log", login);
                        intent.putExtra("Id", myactivitytmodel.get(position).getQuizId());
                        intent.putExtra("ImageUrl", myactivitytmodel.get(position).getImageUrl());
                        intent.putExtra("Title", myactivitytmodel.get(position).getTitle());
                        intent.putExtra("Description", myactivitytmodel.get(position).getDescription());
                        intent.putExtra("QuizStatus", myactivitytmodel.get(position).getStatus());
                        intent.putExtra("json", json.toString());

                        context.startActivity(intent);
                    }
                else if (myactivitytmodel.get(position).getStatus().equals("Details"))
                {
                    Intent intent = new Intent(context, QuizDetails.class);
                    intent.putExtra("Log", login);
                    intent.putExtra("Id", myactivitytmodel.get(position).getQuizId());
                    intent.putExtra("ImageUrl", myactivitytmodel.get(position).getImageUrl());
                    intent.putExtra("Title", myactivitytmodel.get(position).getTitle());
                    intent.putExtra("Description", myactivitytmodel.get(position).getDescription());
                    intent.putExtra("QuizStatus", myactivitytmodel.get(position).getStatus());
                    intent.putExtra("json",json.toString());

                    context.startActivity(intent);
                }
                else {

                    }
            }
        });
    }

    @Override
    public int getItemCount() {
        int a;
        if(myactivitytmodel!=null&&!myactivitytmodel.isEmpty())
        {
            a=myactivitytmodel.size();
        }
        else {
            a=0;
        }
        return a;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView description,status;
        ImageView image;
        public ViewHolder(View itemView) {
            super(itemView);
            context=itemView.getContext();
            title = (TextView) itemView.findViewById(R.id.name);
            status = (TextView) itemView.findViewById(R.id.status);
            description=(TextView) itemView.findViewById(R.id.description);
            image = (ImageView) itemView.findViewById(R.id.image);
        }
    }




}
