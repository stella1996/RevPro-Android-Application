package com.example.admin.revatureapp;

/**
 * Created by home on 3/5/2018.
 */

public class MyActivityModel {
    private String title;
    private String description;
    private  String imageUrl;
    private String quizId;
    private String quizAttempts;
    private String passPercentage;
    private String activityPoint;
    private String status;
    private String categoryName;
    private String category;

    public String getCategoryName() {
        return categoryName;
    }

    public void setCategoryName(String categoryName) {
        this.categoryName = categoryName;
    }

    public String getStatus() {
        return status;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getQuizId() {
        return quizId;
    }



    public void setQuizId(String quizId) {
        this.quizId = quizId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getQuizAttempts() {
        return quizAttempts;
    }

    public void setQuizAttempts(String quizAttempts) {
        this.quizAttempts = quizAttempts;
    }

    public String getPassPercentage() {
        return passPercentage;
    }

    public void setPassPercentage(String passPercentage) {
        this.passPercentage = passPercentage;
    }

    public String getActivityPoint() {
        return activityPoint;
    }

    public void setActivityPoint(String activityPoint) {
        this.activityPoint = activityPoint;
    }

    @Override
    public String toString() {
        return "MyActivityModel{" +
                "title='" + title + '\'' +
                ", description='" + description + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", quizId='" + quizId + '\'' +
                ", quizAttempts='" + quizAttempts + '\'' +
                ", passPercentage='" + passPercentage + '\'' +
                ", activityPoint='" + activityPoint + '\'' +
                '}';
    }

}
