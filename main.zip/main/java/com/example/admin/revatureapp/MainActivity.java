package com.example.admin.revatureapp;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.support.v7.app.AppCompatActivity;
import android.text.Html;
import android.util.Log;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.Profile;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.linkedin.platform.LISessionManager;
import com.linkedin.platform.errors.LIAuthError;
import com.linkedin.platform.listeners.AuthListener;
import com.linkedin.platform.utils.Scope;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.validator.routines.EmailValidator;
import org.apache.http.Header;
import org.apache.http.HttpHeaders;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.TimeZone;


public class MainActivity extends AppCompatActivity {
    static Login login1;
    TextView textView;
    EditText username, password;
    Button button;
    ImageButton imageButton, imageButton1, imageButton2;
    byte[] encodedtoken;
    String key = "token", token;
    String encodedtoken1, fbId, fbName, googleId, googleName, googleEmail;
    Login login = new Login();
    private LoginButton loginButton;
    private SignInButton button1;
    private CallbackManager callbackManager;
    private int RC_SIGN_IN = 0;
    private GoogleSignInClient mGoogleSigninClient = null;
    private Context context;
    JSONObject myObject;
    TextView label1,label2;

    private static Scope buildScope() {
        return Scope.build(Scope.R_BASICPROFILE, Scope.W_SHARE);
    }

    private static String convertInputStreamToString(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String line = "";
        String result = "";
        while ((line = bufferedReader.readLine()) != null)
            result += line;

        inputStream.close();
        System.out.println("InputStream:" + result);

        return result;

    }

    public static boolean emailValidator(String email) {

        boolean valid = EmailValidator.getInstance().isValid(email);
        return valid;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        // Build a GoogleApiClient with access to the Google Sign-In API and the
// options specified by gso.
        // Build a GoogleSignInClient with the options specified by gso.
        mGoogleSigninClient = GoogleSignIn.getClient(this, gso);
        FacebookSdk.sdkInitialize(getApplicationContext());
        setContentView(R.layout.activity_main);
        callbackManager = CallbackManager.Factory.create();
        loginButton = (LoginButton) findViewById(R.id.login_btn);//facebook login invisible butt


        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);
       
        button = (Button) findViewById(R.id.button);
        textView = (TextView) findViewById(R.id.textView);
        imageButton = (ImageButton) findViewById(R.id.imageButton);
        imageButton1 = (ImageButton) findViewById(R.id.imageButton1);
        imageButton2 = (ImageButton) findViewById(R.id.imageButton2);

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, Forgot_Password.class);
                startActivity(intent);
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                context = v.getContext();
                String user = username.getText().toString();
                int userLength = user.length();
                System.out.println(userLength);
                String pass = password.getText().toString();
                if (username.getText().length() == 0) {
                    username.setError("Email cannot be blank ");
                } else if (!emailValidator(user))
                    username.setError("Email is invalid ");
                else if (password.getText().length() == 0) {
                    password.setError("Password cannot be blank ");
                } else {
                    new Login1().execute();

                }
            }  //Normal server authentication
        });
        imageButton1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signInIntent = mGoogleSigninClient.getSignInIntent();
                startActivityForResult(signInIntent, RC_SIGN_IN);
            }
        });
        imageButton2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {     //Linkedin authentication
                linkedinLogin();
            }
        });
        loginButton.setReadPermissions(Arrays.asList("public_profile", "email", "user_friends")); //facebook authentication
        loginButton.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {

            }

            @Override
            public void onCancel() {

            }

            @Override
            public void onError(FacebookException error) {

            }
        });

        LoginManager.getInstance().registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {

                Toast.makeText(getBaseContext(), "Login Successful ", Toast.LENGTH_LONG).show();
                Thread background = new Thread() {
                    public void run() {

                        try {
                            // Thread will sleep for 5 seconds
                            sleep(5 * 1000);
                            // After 5 seconds redirect to another intent
                            Intent i = new Intent(getBaseContext(), DashboardActivity.class);
                            startActivity(i);
                            //Remove activity
                            finish();
                        } catch (Exception e) {

                        }
                    }
                };
                // start thread
                background.start();


                com.facebook.Profile profile = Profile.getCurrentProfile();
                String userId = profile.getId();
                String name = profile.getName();
                System.out.println(userId + name);
                facebookAuthentication(userId, name);

            }

            @Override
            public void onCancel() {
                LoginManager.getInstance().logOut();

            }

            @Override
            public void onError(FacebookException error) {
                String Error = error.toString();
                Toast.makeText(getBaseContext(), Error, Toast.LENGTH_LONG).show();

            }
        });

        imageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                LoginManager.getInstance().logInWithReadPermissions(MainActivity.this, Arrays.asList("public_profile", "email", "user_friends"));
            }
        });
    }

    private void linkedinLogin() {
        final Activity thisActivity = this;
        LISessionManager.getInstance(getApplicationContext()).init(thisActivity, buildScope(), new AuthListener() {
            @Override
            public void onAuthSuccess() {
                Toast.makeText(getBaseContext(), "Login Successful ", Toast.LENGTH_LONG).show();


            }

            @Override
            public void onAuthError(LIAuthError error) {

            }
        }, true);


    }

    public String timeZone() {
        TimeZone time = TimeZone.getDefault();
        System.out.println(time.getID());
        return time.getID();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            // The Task returned from this call is always completed, no need to attach
            // a listener.
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        } else if (requestCode == 64206)
            callbackManager.onActivityResult(requestCode, resultCode, data);
        else {
            LISessionManager.getInstance(getApplicationContext()).onActivityResult(this, requestCode, resultCode, data);
            Toast.makeText(getBaseContext(), "Login Successful ", Toast.LENGTH_LONG).show();
            Intent i = new Intent(getBaseContext(), DashboardActivity.class);
            startActivity(i);
        }


    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {

            GoogleSignInAccount account = completedTask.getResult(ApiException.class);

            String username = account.getDisplayName();
            String email = account.getEmail();
            String id = account.getId();
            googleAuthentication(id,username,email);



        } catch (ApiException e) {
            // The ApiException status code indicates the detailed failure reason.
            // Please refer to the GoogleSignInStatusCodes class reference for more information.
            Log.w("ERROR", "signInResult:failed code=" + e.getStatusCode());

        }
    }

    @Override
    public void onBackPressed() {
        new AlertDialog.Builder(this).setIcon(android.R.drawable.ic_dialog_alert).setTitle("Exit")
                .setMessage("Are you sure?")
                .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {


                        finish();
                    }
                }).setNegativeButton("no", null).show();
    }

    public void googleAuthentication(String userId, String name, String email) {
        this.googleId = userId;
        this.googleName = name;
        this.googleEmail = email;
        new GoogleAuth().execute();
    }

    public void facebookAuthentication(String userId, String name) {
        this.fbId = userId;
        this.fbName = name;
        new FbAuth().execute();
    }

    public class Login1 extends AsyncTask<String, String, String> {


        public static final String MY_PREFS_NAME = "MyPrefsFile";
        String user = username.getText().toString();
        String pass = password.getText().toString();
        String timeZone = timeZone();
        InputStream inputStream = null;
        String result;
        ProgressDialog progress;

        @Override

        protected void onPreExecute() {
            progress = new ProgressDialog(MainActivity.this);
            progress.setMessage("Processing your login request");
            progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progress.setIndeterminate(true);
            progress.show();
        }

        @Override
        protected void onPostExecute(String s) {


            try {
                JSONObject myObject = new JSONObject(result);
                progress.cancel();
                String statusCode = myObject.getString("statusCode");
                System.out.println(statusCode);
                String description = myObject.getString("description");
                if(statusCode.equals("SC001")) {
                    token = myObject.getJSONObject("data").getString("token");
                    System.out.println(token);
                    encodedtoken = Base64.encodeBase64(token.getBytes(Charset.forName("UTF-8")));


                    login.setEncodedtoken(encodedtoken);
                    encodedtoken1 = new String(encodedtoken);
                    login.setToken(encodedtoken1);
                    System.out.println(login.getToken());
                }
                login1 = login;
                if (statusCode.equals("SC001")) {
                    Toast.makeText(getBaseContext(), description, Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                    intent.putExtra("Login_Class", login);
                    JSONObject data = myObject.getJSONObject("data");
                    JSONObject intern=data.getJSONObject("intern");
                    intent.putExtra("JSON_RESPONSE", intern.toString());
                    startActivity(intent);
                }
               else {
                    Toast.makeText(getBaseContext(), description, Toast.LENGTH_LONG).show();

                }

            } catch (Exception e) {
                e.printStackTrace();
            }
        }


        @Override
        protected String doInBackground(String... strings) {
            login.setUsername(user);
            login.setPassword(pass);
            login.setTimeZone(timeZone);
            try {
                String userId = login.getUsername();
                String pwd = login.getPassword();
                String userAgent = "UserAgent: " + System.getProperty("http.agent");
                String u = "https://qa2.revature.com/core/resources/interns/login";
                URL url = new URL(u);
                String host = "Host:" + url.getHost();
                String Device = "Device:" + Build.DEVICE;
                String OS = "OS:" + Build.VERSION.SDK_INT;
                System.out.println(userAgent);
                System.out.println(host);
                System.out.println(Device);
                String auth = user + ":" + pass;
                byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("UTF-8")));
                String authHeader = "Basic " + new String(encodedAuth);
                String post = R.string.baseurl + "core/resources/interns/login";
                System.out.println("post" + post);

                System.out.println(authHeader);
                String posturl = "https://qa2.revature.com/core/resources/interns/login";
                HttpPost request = new HttpPost(posturl);
                request.setHeader(HttpHeaders.AUTHORIZATION, authHeader);
                request.setHeader("Accept", "application/json");
                request.setHeader("Content-type", "text/plain");
                byte[] encodedAuthId = Base64.encodeBase64(userId.getBytes(Charset.forName("UTF-8")));
                String encodedusername = new String(encodedAuthId);
                byte[] encodedAuthPwd = Base64.encodeBase64(pwd.getBytes(Charset.forName("UTF-8")));
                String encodedPassword = new String(encodedAuthPwd);
                byte[] encodedUserHost = Base64.encodeBase64(host.getBytes(Charset.forName("UTF-8")));
                byte[] encodedUserDevice = Base64.encodeBase64(Device.getBytes(Charset.forName("UTF-8")));
                byte[] encodedUserOS = Base64.encodeBase64(OS.getBytes(Charset.forName("UTF-8")));
                byte[] encodedUserAgent = Base64.encodeBase64(userAgent.getBytes(Charset.forName("UTF-8")));
                String userHost = new String(encodedUserHost);
                String userDevice = new String(encodedUserDevice);
                String userOS = new String(encodedUserOS);
                String Agent = new String(encodedUserAgent);
                System.out.println(userHost);
                System.out.println(userDevice);
                System.out.println(userOS);
                System.out.println(Agent);
                String encodeduserLoc = userHost + userDevice + userOS + Agent;
                System.out.println(encodeduserLoc);
                HttpClient client = new DefaultHttpClient();
                JSONObject json = new JSONObject();
                json.accumulate("email", encodedusername);
                json.accumulate("password", encodedPassword);
                json.accumulate("userAccessLocation", encodeduserLoc);
                json.accumulate("timeZone", timeZone);
                String postData = json.toString();
                byte[] encodedPostData = Base64.encodeBase64(postData.getBytes(Charset.forName("UTF-8")));
                String userData = new String(encodedPostData);
                StringEntity entity = new StringEntity(userData);

                request.setEntity(entity);
                System.out.println(userData);


                HttpResponse response = client.execute(request);
                inputStream = response.getEntity().getContent();

                Header[] headers = response.getAllHeaders();
                for (Header header : headers) {
                    System.out.println("Key : " + header.getName()
                            + " ,Value : " + header.getValue());

                }
                int statusCode = response.getStatusLine().getStatusCode();
                String statusLine = response.getStatusLine().toString();
                System.out.println(statusCode);
                System.out.println(statusLine);
                if (inputStream != null) {
                    result = convertInputStreamToString(inputStream);
                } else
                    result = "Did not work!";
                return null;
            } catch (Exception e) {
                System.out.println("error:" + e);
            }

            return null;
        }
    }

    class FbAuth extends AsyncTask<String, String, String>

    {
        InputStream inputStream = null;
        String result;

        @Override
        protected String doInBackground(String... strings) {

            try {
                HttpPost post = new HttpPost("https://qa2.revature.com/core/resources/interns/fblogin");
                post.setHeader("Accept", "application/json");
                post.setHeader("Content-type", "application/json");
                HttpClient client = new DefaultHttpClient();

                String userAgent = "UserAgent: " + System.getProperty("http.agent");
                String u = "https://qa2.revature.com/core/resources/interns/fblogin";
                URL url = new URL(u);
                String host = "Host:" + url.getHost();
                String Device = "Device:" + Build.DEVICE;
                String OS = "OS:" + Build.VERSION.SDK_INT;
                String userAccessLocation = host + Device + OS + userAgent;
                JSONObject json = new JSONObject();
                json.accumulate("accountId", fbId);
                json.accumulate("accountName", "Facebook");
                json.accumulate("fullName", fbName);
                json.accumulate("isSocialLogin", "Yes");
                json.accumulate("timeZone", timeZone());
                json.accumulate("userAccessLocation", userAccessLocation);
                String postData = json.toString();
                String userData = new String(postData);
                StringEntity entity = new StringEntity(userData);

                post.setEntity(entity);
                System.out.println(userData);


                HttpResponse response = client.execute(post);
                inputStream = response.getEntity().getContent();


                int statusCode = response.getStatusLine().getStatusCode();
                String statusLine = response.getStatusLine().toString();
                System.out.println(statusCode);
                System.out.println(statusLine);
                if (inputStream != null) {
                    result = convertInputStreamToString(inputStream);
                    System.out.println("res" + result);
                } else
                    result = "Did not work!";
                return null;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            try {
                JSONObject myObject = new JSONObject(result);
                String statusCode = myObject.getString("statusCode");
                String description = myObject.getString("description");
                token = myObject.getJSONObject("data").getString("token");
                System.out.println(token);
                encodedtoken = Base64.encodeBase64(token.getBytes(Charset.forName("UTF-8")));
                login.setEncodedtoken(encodedtoken);
                encodedtoken1 = new String(encodedtoken);
                login.setToken(encodedtoken1);
                System.out.println(login.getToken());
                if (statusCode.equals("SC001")) {
                    Toast.makeText(getBaseContext(), description, Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                    intent.putExtra("Login_Class", login);
                    intent.putExtra("JSON_RESPONSE", myObject.toString());
                    startActivity(intent);
                } else {

                    Toast.makeText(getBaseContext(), description, Toast.LENGTH_LONG).show();

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }

    class GoogleAuth extends AsyncTask<String, String, String>

    {
        InputStream inputStream = null;
        String result;

        @Override
        protected String doInBackground(String... strings) {

            try {
                HttpPost post = new HttpPost("https://qa2.revature.com/core/resources/interns/gpluslogin");
                post.setHeader("Accept", "application/json");
                post.setHeader("Content-type", "application/json");
                HttpClient client = new DefaultHttpClient();

                String userAgent = "UserAgent: " + System.getProperty("http.agent");
                String u = "https://qa2.revature.com/core/resources/interns/gpluslogin";
                URL url = new URL(u);
                String host = "Host:" + url.getHost();
                String Device = "Device:" + Build.DEVICE;
                String OS = "OS:" + Build.VERSION.SDK_INT;
                String userAccessLocation = host + Device + OS + userAgent;
                JSONObject json = new JSONObject();
                json.accumulate("accountId", googleId);
                json.accumulate("accountName", "GPlus");
                json.accumulate("fullName", googleName);
                json.accumulate("isSocialLogin", "Yes");
                json.accumulate("timeZone", timeZone());
                json.accumulate("shortName", "REV");
                json.accumulate("email", googleEmail);
                json.accumulate("userAccessLocation", userAccessLocation);
                String postData = json.toString();
                String userData = new String(postData);
                StringEntity entity = new StringEntity(userData);

                post.setEntity(entity);
                System.out.println(userData);


                HttpResponse response = client.execute(post);
                inputStream = response.getEntity().getContent();


                int statusCode = response.getStatusLine().getStatusCode();
                String statusLine = response.getStatusLine().toString();
                System.out.println(statusCode);
                System.out.println(statusLine);
                if (inputStream != null) {
                    result = convertInputStreamToString(inputStream);
                    System.out.println("res" + result);
                } else
                    result = "Did not work!";
                return null;
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            try {
               JSONObject myObject = new JSONObject(result);
                String statusCode = myObject.getString("statusCode");
                String description = myObject.getString("description");
                if (statusCode.equals("SC001")) {
                    token = myObject.getJSONObject("data").getString("token");

                    System.out.println(token);
                    encodedtoken = Base64.encodeBase64(token.getBytes(Charset.forName("UTF-8")));
                    login.setEncodedtoken(encodedtoken);
                    encodedtoken1 = new String(encodedtoken);
                    login.setToken(encodedtoken1);
                    System.out.println(login.getToken());
                }
                if (statusCode.equals("SC001")) {
                    Log.v("Log in check", "Passed");
                    Toast.makeText(getBaseContext(), description, Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(MainActivity.this, DashboardActivity.class);
                    intent.putExtra("Login_Class", login);
                    JSONObject data = myObject.getJSONObject("data");
                    JSONObject intern=data.getJSONObject("intern");
                    intent.putExtra("JSON_RESPONSE", intern.toString());
                    startActivity(intent);
                } else {
                    Log.v("Log in check", "fail");

                    Toast.makeText(getBaseContext(), description, Toast.LENGTH_LONG).show();

                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }



}
