package com.example.admin.revatureapp;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;
import org.w3c.dom.Text;

import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

public class QuizDetails extends AppCompatActivity {
String id,quizImage,description,quizAttempts,passPercentage,title,quizStatus;
    Button button;

    DrawerLayout drawer;
    NavigationView navigationView;
    TextView emailid,name;
    TextView textView,quizdescription,descriptionlabel;
    Toolbar quiztitle;
    ImageView imageview;
    Login login;
    String token,result,activityPoint,timeSpent;
JSONObject LoginJson;
    InputStream inputStream=null;
    Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz_details);
        context=getApplicationContext();
        login = (Login) getIntent().getSerializableExtra("Log");
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
descriptionlabel=(TextView)findViewById(R.id.textView5);
        new QuizDetail().execute();
        textView=(TextView)findViewById(R.id.textView4);
        quiztitle=(Toolbar)findViewById(R.id.toolbar);
        imageview=(ImageView)findViewById(R.id.quizimage);
        quizdescription=(TextView)findViewById(R.id.description);
        button = (Button)findViewById(R.id.start);
        id=getIntent().getStringExtra("Id");
        title=getIntent().getStringExtra("Title");
        quizImage=getIntent().getStringExtra("ImageUrl");
               quizStatus=getIntent().getStringExtra("QuizStatus");
            if (quizStatus!=null && quizStatus.equals("Re-Take"))
                button.setText("START");
            else if (quizStatus!=null && quizStatus.equals("Locked")) {

            } else if (quizStatus!=null && quizStatus.equals("In-Progress")) {
                button.setText("RESUME");
            }
        else
        {
            button.setText("START");

        }
        quiztitle.setTitle(title);
try
    {
        String json1=DashboardActivity.getDefaults("json",context);
        LoginJson = new JSONObject(json1);

    }catch (Exception e)
        {
            e.printStackTrace();
        }

        new DownLoadImageTask(imageview).execute(quizImage);

button.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
          if (quizStatus!=null && quizStatus.equals("Re-Take"))
              new StartQuiz().execute();
          else if (quizStatus!=null && quizStatus.equals("Locked")) {

          } else if (quizStatus!=null && quizStatus.equals("In-Progress")) {
              new ResumeQuiz().execute();
          }
        else
        {
            new StartQuiz().execute();
        }
    }
});
    }

    class QuizDetail extends AsyncTask<String,String,String>
    {

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }


        @Override
        protected String doInBackground(String... strings) {
            token = login.getToken();

            try {
                HttpGet get = new HttpGet("https://qa2.revature.com/core/resources/secure/quiz/"+id+ "/details");
                get.setHeader("Accept", "application/json");
                get.setHeader("Authorization", token);
                HttpClient httpclient = new DefaultHttpClient();
                HttpResponse res = httpclient.execute(get);

                inputStream = res.getEntity().getContent();


                if (inputStream != null) {
                    result = convertInputStreamToString(inputStream);
                } else {
                    result = "Did not work!";
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }
        @Override
        protected void onPostExecute(String s) {
                       try {
                           JSONObject obj = new JSONObject(result);
                           JSONObject json = obj.getJSONObject("data");

           
                           if (json.has("description")) {
                               description = json.getString("description");
                               descriptionlabel.setVisibility(View.VISIBLE);
                               quizdescription.setText(description);
                          }
                          else {
                               descriptionlabel.setVisibility(View.GONE);

                           }
                               if (json.has("timeSpent")) {
                                   timeSpent = json.getString("timeSpent");
                               }

                           activityPoint= json.getString("activityPoint");
                           passPercentage=json.getString("passPercentage");
                           if(json.has("internAttempts")) {
                               int remainingattempts = 0;
                               int internAttempts = Integer.parseInt(json.getString("internAttempts"));
                               int qAttempt = Integer.parseInt(json.getString("quizAttempts"));
                               remainingattempts = qAttempt - internAttempts;
                               if (qAttempt == remainingattempts) {
                                   String instruction = "ActivityPoint:" +"  "+ activityPoint + "\r\n\n" + "PassPercentage:" +"  "+ passPercentage + "\r\n\n" + "QuizAttempts:" +"  "+ qAttempt;
                                   textView.setText(instruction);

                               } else {
                                   String instruction = "ActivityPoint:" +"  "+ activityPoint + "\r\n" + "PassPercentage:" +"  "+ passPercentage + "\r\n" + "RemainingAttempts:" +"  "+ remainingattempts;
                                   textView.setText(instruction);

                               }
                           }
                           else
                           {
                               int qAttempt = Integer.parseInt(json.getString("quizAttempts"));
                               String instruction = "ActivityPoint:" +"  "+ activityPoint + "\r\n" + "PassPercentage:" +"  "+ passPercentage + "\r\n" + "QuizAttempts:" +"  "+ qAttempt;
                               textView.setText(instruction);

                           }
                       }
                       catch (Exception e)
                       {
                           e.printStackTrace();
                       }



        }



    }
    private static String convertInputStreamToString(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String line = "";
        StringBuilder result = new StringBuilder();
        while ((line = bufferedReader.readLine()) != null)
            result.append(line);

        inputStream.close();
        System.out.println("InputStream:" + result.toString());

        return result.toString();
    }

    private class DownLoadImageTask extends AsyncTask<String,Void,Bitmap>{
        ImageView imageView;

        public DownLoadImageTask(ImageView imageView){
            this.imageView = imageView;
        }

        /*
            doInBackground(Params... params)
                Override this method to perform a computation on a background thread.
         */
        protected Bitmap doInBackground(String...urls){
            String urlOfImage = urls[0];
            Bitmap logo = null;
            try{
                InputStream is = new URL(urlOfImage).openStream();
                /*
                    decodeStream(InputStream is)
                        Decode an input stream into a bitmap.
                 */
                logo = BitmapFactory.decodeStream(is);
            }catch(Exception e){ // Catch the download exception
                e.printStackTrace();
            }
            return logo;
        }

        /*
            onPostExecute(Result result)
                Runs on the UI thread after doInBackground(Params...).
         */
        protected void onPostExecute(Bitmap result){
            imageView.setImageBitmap(result);
        }
    }

    private class StartQuiz extends AsyncTask<String,String,String>
    {
        ProgressDialog progress;

        @Override
        protected void onPreExecute() {
            progress=new ProgressDialog(QuizDetails.this);
            progress.setMessage("Questions are loading!!");
            progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progress.setIndeterminate(true);
            progress.show();
        }

        @Override
        protected String doInBackground(String... strings) {
            token=login.getToken();
            System.out.println(id);
            String url="https://qa2.revature.com/core/resources/secure/quiz/"+id+"/question/2/Dashboard";
            System.out.println(url);

            try

            {
                HttpGet get = new HttpGet(url);
                get.setHeader("Accept", "application/json");
                get.setHeader("Authorization", token);
                HttpClient httpclient = new DefaultHttpClient();
                HttpResponse res = httpclient.execute(get);

                inputStream = res.getEntity().getContent();


                if (inputStream != null) {
                    result = convertInputStreamToString(inputStream);
                } else {
                    result = "Did not work!";
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String s) {
           try
           {
               JSONObject obj = new JSONObject(result);
               String statusCode=obj.getString("statusCode");
               String description=obj.getString("description");
               String arr[]=description.split(",");
               if(statusCode.equals("SC005"))
               {
                   progress.cancel();
                   System.out.println("yes");
                   Intent intent = new Intent(QuizDetails.this,Quiz.class);
                   intent.putExtra("JSON",LoginJson.toString());
                   intent.putExtra("json",obj.toString());
                   intent.putExtra("id",id);
                   intent.putExtra("Login",login);
                   intent.putExtra("title",title);
                   intent.putExtra("timeSpent",timeSpent);
intent.putExtra("status",quizStatus);
                   startActivity(intent);
               }
               else
               {
                   progress.cancel();
                   new android.app.AlertDialog.Builder(QuizDetails.this).setIcon(android.R.drawable.ic_dialog_alert).setTitle("Warning")
                           .setMessage("Quiz :"+arr[1]+" is In Progress and you have to save/submit it to start this quiz.\nYou can resume it from DashBoard page.\n" +
                                   "\n")
                           .setPositiveButton("GOBACK", new DialogInterface.OnClickListener() {
                               @Override
                               public void onClick(DialogInterface dialog, int which) {
                                   Intent intent = new Intent(QuizDetails.this,DashboardActivity.class);
                                   intent.putExtra("Login_Class",login);
                                   intent.putExtra("JSON_RESPONSE",LoginJson.toString());
                                   startActivity(intent);

                               }
                           }
                           ).setNegativeButton("", null).show();
               }
           }catch(Exception e)
           {
               e.printStackTrace();
           }
        }
    }
    private class ResumeQuiz extends AsyncTask<String,String,String>
    {
        ProgressDialog progress;
        @Override
        protected void onPreExecute() {
            progress=new ProgressDialog(QuizDetails.this);
            progress.setMessage("Questions are loading!!");
            progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progress.setIndeterminate(true);
            progress.show();
        }
        @Override
        protected String doInBackground(String... strings) {
            token=login.getToken();
            System.out.println(id);
            String url="https://qa2.revature.com/core/resources/secure/quiz/"+id+"/question/3/Dashboard";
            System.out.println(url);

            try

            {
                HttpGet get = new HttpGet(url);
                get.setHeader("Accept", "application/json");
                get.setHeader("Authorization", token);
                HttpClient httpclient = new DefaultHttpClient();
                HttpResponse res = httpclient.execute(get);

                inputStream = res.getEntity().getContent();


                if (inputStream != null) {
                    result = convertInputStreamToString(inputStream);
                } else {
                    result = "Did not work!";
                }
            }
            catch(Exception e)
            {
                e.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPostExecute(String s) {
            try
            {
                JSONObject obj = new JSONObject(result);
                String statusCode=obj.getString("statusCode");
                String description=obj.getString("description");
                String arr[]=description.split(",");

                if(statusCode.equals("SC005"))
                {
                    System.out.println("yes");
                    Intent intent = new Intent(QuizDetails.this,Quiz.class);
                    intent.putExtra("json",obj.toString());
                    intent.putExtra("JSON",LoginJson.toString());
                    intent.putExtra("title",title);
                    intent.putExtra("id",id);
                    intent.putExtra("Login",login);
                    intent.putExtra("timeSpent",timeSpent);
                    intent.putExtra("status",quizStatus);

                    startActivity(intent);
                }
                else
                {
                    progress.cancel();
                    new android.app.AlertDialog.Builder(QuizDetails.this).setIcon(android.R.drawable.ic_dialog_alert).setTitle("Warning")
                            .setMessage("Quiz :"+arr[1]+" is In Progress and you have to save/submit it to start this quiz.\nYou can resume it from DashBoard page.\n" +
                                    "\n")
                            .setPositiveButton("GOBACK", new DialogInterface.OnClickListener() {
                                        @Override
                                        public void onClick(DialogInterface dialog, int which) {
                                            Intent intent = new Intent(QuizDetails.this,DashboardActivity.class);
                                            intent.putExtra("Login_Class",login);
                                            intent.putExtra("JSON_RESPONSE",LoginJson.toString());
                                            startActivity(intent);

                                        }
                                    }
                            ).setNegativeButton("", null).show();
                }
            }catch(Exception e)
            {
                e.printStackTrace();
            }
        }
    }
}

