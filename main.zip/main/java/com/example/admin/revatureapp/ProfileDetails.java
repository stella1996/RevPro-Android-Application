package com.example.admin.revatureapp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;


/**
 * Created by home on 2/16/2018.
 */
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ProfileDetails implements Serializable{

    private String id;
    private String email;
    private String secondaryEmail;
    private String tempEmail;
    private String contactNo;
    private String otherDegree;
    private String collegeCity;
    private String collegeState;
    private String isActive;
    private String univId;
    private String univName;
    private String univcountryCode;
    @JsonIgnore
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern ="dd-MM-yyyy hh:mm:ss" )
    private LocalDateTime signedupOn;
    @JsonIgnore
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern ="dd-MM-yyyy hh:mm:ss" )
    private LocalDateTime startDate;
    @JsonIgnore
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern ="dd-MM-yyyy hh:mm:ss" )
    private LocalDateTime endDate;
    private String activationKey;
    private String isDeleted;
    private String isDeletedOn;
    private String workAuthorization;
    private String desiredPay;
    private String preferedCareerPath;
    private String sourceOfEntry;
    private String considerForEmployment;
    private String resetPasswordkey;
    private String internType;
    private String tmpPassword;
    private String traineeProjectCount;
    private String checkBox;
    private String gplusId;
    private String fbId;
    private String firstName;
    private String lastName;
    private String sendKey;
    private String minor;
    private String accountId;
    private String userId;
    private String resumeSource;
    private String campus;
    private String major_Name;
    private String address;
    private String dob;
    private String photo;
    private String photoType;
    private String profilePublish;
    private String countryId;
    private String countryName;
    private String countryCode;
    private String CountryDescription;
    private String state;
    private String stateId;
    private String stateName;
    private String stateCode;
    private String city;
    private String currentCity;
    private String currentState;
    private String tamilnadu;
    private String zip;
    private String marketReady;
    private String aboutMe;
    private String designation;
    @JsonIgnore
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern ="dd-MM-yyyy hh:mm:ss" )
    private LocalDateTime activatedOn;
    private String fullName;
    @JsonIgnore
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern ="dd-MM-yyyy hh:mm:ss" )
    private LocalDateTime lastLoggedTime;
    @JsonIgnore
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern ="dd-MM-yyyy hh:mm:ss" )
    private LocalDateTime currentLoggedTime;
    private String profileScore;
    private String profileCompPercentage;
    private String degreeId;
    private String degreeName;
    private String passedoutYear;
    private String passedoutMonth;
    private String isContactNoUpDated;
    private String interest;
    private String type;
    @JsonIgnore
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern ="dd-MM-yyyy hh:mm:ss" )
    private LocalDateTime graduationDate;
    private String otherMajor;
    private String referralCode;
    private String tempPassword;
    private String majorId;
    private String majorName;
    private String isLoggedIn;
    private String isOptOutDashboard;
    private String salesforceTrainingStatus;
    private String sfTrainingStatusUpDatedOn;
    private String isProfieAssessmentCompleted;
    private String password;
    private String securityToken;
    private String oldPassword;
    private String imageUrl;
    private String startDay;
    private String endDay;
    private String currentMentor;
    @JsonIgnore
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern ="dd-MM-yyyy hh:mm:ss" )
    private LocalDateTime profileUpDateTime;
    private List<String> internships;
    private String candiDateType;
    private String profileName;
    private String socialAccountId;
    private String accountName;
    private String friendReferralCode;
    private String showPrimaryEmailOnPublicProfile;
    private String showContactNoOnPublicProfile;
    private String showZipCodeOnPublicProfile;
    private String showUniversityOnPublicProfile;
    private String showDegreeOnPublicProfile;
    private String showMajorOnPublicProfile;
    private String showGraduationDateOnPublicProfile;
    private String showVeteran;
    private String veteranBranch;
    private String militrayStatus;
    private String otherStatus;
    private String otherUniversity;
    private String veteranClearance;
    private String userAccessLocation;
    private String timeZone;
    private String isTimeZoneUpDated;
    private String isSocialLogin;
    @JsonIgnore
    @JsonFormat(shape = JsonFormat.Shape.STRING,pattern ="dd-MM-yyyy hh:mm:ss" )
    private LocalDateTime profileUpDatedTime;
    private String otherSourceOfEntry;
    private String shortName;
    private String academicName;
    private String isPayableCandiDate;
    private String planExpiresOn;
    private String isInternUpDate;
    private String showCurrentCityOnPublicProfile;
    private String showCurrentStateOnPublicProfile;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSecondaryEmail() {
        return secondaryEmail;
    }

    public void setSecondaryEmail(String secondaryEmail) {
        this.secondaryEmail = secondaryEmail;
    }

    public String getTempEmail() {
        return tempEmail;
    }

    public void setTempEmail(String tempEmail) {
        if(tempEmail!="null")
        this.tempEmail = tempEmail;
        else
            this.tempEmail=null;
    }

    public String getContactNo() {
        return contactNo;
    }

    public void setContactNo(String contactNo) {
        this.contactNo = contactNo;
    }

    public String getOtherDegree() {
        return otherDegree;
    }

    public void setOtherDegree(String otherDegree) {
        this.otherDegree = otherDegree;
    }

    public String getCollegeCity() {
        return collegeCity;
    }

    public void setCollegeCity(String collegeCity) {
        this.collegeCity = collegeCity;
    }

    public String getCollegeState() {
        return collegeState;
    }

    public void setCollegeState(String collegeState) {
        this.collegeState = collegeState;
    }

    public String getIsActive() {
        return isActive;
    }

    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    public String getUnivId() {
        return univId;
    }

    public void setUnivId(String univId) {
        this.univId = univId;
    }

    public String getUnivName() {
        return univName;
    }

    public void setUnivName(String univName) {
        this.univName = univName;
    }

    public String getUnivcountryCode() {
        return univcountryCode;
    }

    public void setUnivcountryCode(String univcountryCode) {
        this.univcountryCode = univcountryCode;
    }



    public String getActivationKey() {
        return activationKey;
    }

    public void setActivationKey(String activationKey) {
        this.activationKey = activationKey;
    }

    public String getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(String isDeleted) {
        this.isDeleted = isDeleted;
    }

    public String getIsDeletedOn() {
        return isDeletedOn;
    }

    public void setIsDeletedOn(String isDeletedOn) {
        this.isDeletedOn = isDeletedOn;
    }

    public String getWorkAuthorization() {
        return workAuthorization;
    }

    public void setWorkAuthorization(String workAuthorization) {
        this.workAuthorization = workAuthorization;
    }

    public String getDesiredPay() {
        return desiredPay;
    }

    public void setDesiredPay(String desiredPay) {
        this.desiredPay = desiredPay;
    }

    public String getPreferedCareerPath() {
        return preferedCareerPath;
    }

    public void setPreferedCareerPath(String preferedCareerPath) {
        this.preferedCareerPath = preferedCareerPath;
    }

    public String getSourceOfEntry() {
        return sourceOfEntry;
    }

    public void setSourceOfEntry(String sourceOfEntry) {
        this.sourceOfEntry = sourceOfEntry;
    }

    public String getConsiderForEmployment() {
        return considerForEmployment;
    }

    public void setConsiderForEmployment(String considerForEmployment) {
        this.considerForEmployment = considerForEmployment;
    }

    public String getResetPasswordkey() {
        return resetPasswordkey;
    }

    public void setResetPasswordkey(String resetPasswordkey) {
        this.resetPasswordkey = resetPasswordkey;
    }

    public String getInternType() {
        return internType;
    }

    public void setInternType(String internType) {
        this.internType = internType;
    }

    public String getTmpPassword() {
        return tmpPassword;
    }

    public void setTmpPassword(String tmpPassword) {
        this.tmpPassword = tmpPassword;
    }

    public String getTraineeProjectCount() {
        return traineeProjectCount;
    }

    public void setTraineeProjectCount(String traineeProjectCount) {
        this.traineeProjectCount = traineeProjectCount;
    }

    public String getCheckBox() {
        return checkBox;
    }

    public void setCheckBox(String checkBox) {
        this.checkBox = checkBox;
    }

    public String getGplusId() {
        return gplusId;
    }

    public void setGplusId(String gplusId) {
        this.gplusId = gplusId;
    }

    public String getFbId() {
        return fbId;
    }

    public void setFbId(String fbId) {
        this.fbId = fbId;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getSendKey() {
        return sendKey;
    }

    public void setSendKey(String sendKey) {
        this.sendKey = sendKey;
    }

    public String getMinor() {
        return minor;
    }

    public void setMinor(String minor) {
        this.minor = minor;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getResumeSource() {
        return resumeSource;
    }

    public void setResumeSource(String resumeSource) {
        this.resumeSource = resumeSource;
    }

    public String getCampus() {
        return campus;
    }

    public void setCampus(String campus) {
        this.campus = campus;
    }

    public String getMajor_Name() {
        return major_Name;
    }

    public void setMajor_Name(String major_Name) {
        this.major_Name = major_Name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        if(dob!="null")
        this.dob = dob;
        else
            this.dob=null;
    }

    public String getPhoto() {
        return photo;
    }

    public void setPhoto(String photo) {
        this.photo = photo;
    }

    public String getPhotoType() {
        return photoType;
    }

    public void setPhotoType(String photoType) {
        this.photoType = photoType;
    }

    public String getProfilePublish() {
        return profilePublish;
    }

    public void setProfilePublish(String profilePublish) {
        this.profilePublish = profilePublish;
    }

    public String getCountryId() {
        return countryId;
    }

    public void setCountryId(String countryId) {
        this.countryId = countryId;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryDescription() {
        return CountryDescription;
    }

    public void setCountryDescription(String countryDescription) {
        CountryDescription = countryDescription;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
      if(state!="null")
          this.state = state;
      else
          this.state=null;
    }

    public String getStateId() {
        return stateId;
    }

    public void setStateId(String stateId) {
        this.stateId = stateId;
    }

    public String getStateName() {
        return stateName;
    }

    public void setStateName(String stateName) {
        this.stateName = stateName;
    }

    public String getStateCode() {
        return stateCode;
    }

    public void setStateCode(String stateCode) {
        this.stateCode = stateCode;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getCurrentCity() {
        return currentCity;
    }

    public void setCurrentCity(String currentCity) {
        this.currentCity = currentCity;
    }

    public String getCurrentState() {
        return currentState;
    }

    public void setCurrentState(String currentState) {
        this.currentState = currentState;
    }

    public String getTamilnadu() {
        return tamilnadu;
    }

    public void setTamilnadu(String tamilnadu) {
        this.tamilnadu = tamilnadu;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getMarketReady() {
        return marketReady;
    }

    public void setMarketReady(String marketReady) {
        this.marketReady = marketReady;
    }

    public String getAboutMe() {
        return aboutMe;
    }

    public void setAboutMe(String aboutMe) {
        this.aboutMe = aboutMe;
    }

    public String getDesignation() {
        return designation;
    }

    public void setDesignation(String designation) {
        this.designation = designation;
    }


    public String getProfileScore() {
        return profileScore;
    }

    public void setProfileScore(String profileScore) {
        this.profileScore = profileScore;
    }

    public String getProfileCompPercentage() {
        return profileCompPercentage;
    }

    public void setProfileCompPercentage(String profileCompPercentage) {
        this.profileCompPercentage = profileCompPercentage;
    }

    public String getDegreeId() {
        return degreeId;
    }

    public void setDegreeId(String degreeId) {
        this.degreeId = degreeId;
    }

    public String getDegreeName() {
        return degreeName;
    }

    public void setDegreeName(String degreeName) {
        this.degreeName = degreeName;
    }

    public String getPassedoutYear() {
        return passedoutYear;
    }

    public void setPassedoutYear(String passedoutYear) {
        this.passedoutYear = passedoutYear;
    }

    public String getPassedoutMonth() {
        return passedoutMonth;
    }

    public void setPassedoutMonth(String passedoutMonth) {
        this.passedoutMonth = passedoutMonth;
    }

    public String getIsContactNoUpDated() {
        return isContactNoUpDated;
    }

    public void setIsContactNoUpDated(String isContactNoUpDated) {
        this.isContactNoUpDated = isContactNoUpDated;
    }

    public String getInterest() {
        return interest;
    }

    public void setInterest(String interest) {
        this.interest = interest;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }


    public String getOtherMajor() {
        return otherMajor;
    }

    public void setOtherMajor(String otherMajor) {
        this.otherMajor = otherMajor;
    }

    public String getReferralCode() {
        return referralCode;
    }

    public void setReferralCode(String referralCode) {
        this.referralCode = referralCode;
    }

    public String getTempPassword() {
        return tempPassword;
    }

    public void setTempPassword(String tempPassword) {
        this.tempPassword = tempPassword;
    }

    public String getMajorId() {
        return majorId;
    }

    public void setMajorId(String majorId) {
        this.majorId = majorId;
    }

    public String getMajorName() {
        return majorName;
    }

    public void setMajorName(String majorName) {
        this.majorName = majorName;
    }

    public String getIsLoggedIn() {
        return isLoggedIn;
    }

    public void setIsLoggedIn(String isLoggedIn) {
        this.isLoggedIn = isLoggedIn;
    }

    public String getIsOptOutDashboard() {
        return isOptOutDashboard;
    }

    public void setIsOptOutDashboard(String isOptOutDashboard) {
        this.isOptOutDashboard = isOptOutDashboard;
    }

    public String getSalesforceTrainingStatus() {
        return salesforceTrainingStatus;
    }

    public void setSalesforceTrainingStatus(String salesforceTrainingStatus) {

        this.salesforceTrainingStatus = salesforceTrainingStatus;
    }

    public String getSfTrainingStatusUpDatedOn() {
        return sfTrainingStatusUpDatedOn;
    }

    public void setSfTrainingStatusUpDatedOn(String sfTrainingStatusUpDatedOn) {
        if(sfTrainingStatusUpDatedOn!="null")
        this.sfTrainingStatusUpDatedOn = sfTrainingStatusUpDatedOn;
        else
            this.sfTrainingStatusUpDatedOn=null;
    }

    public String getIsProfieAssessmentCompleted() {
        return isProfieAssessmentCompleted;
    }

    public void setIsProfieAssessmentCompleted(String isProfieAssessmentCompleted) {
        this.isProfieAssessmentCompleted = isProfieAssessmentCompleted;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSecurityToken() {
        return securityToken;
    }

    public void setSecurityToken(String securityToken) {
        this.securityToken = securityToken;
    }

    public String getOldPassword() {
        return oldPassword;
    }

    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public String getStartDay() {
        return startDay;
    }

    public void setStartDay(String startDay) {
        this.startDay = startDay;
    }

    public String getEndDay() {
        return endDay;
    }

    public void setEndDay(String endDay) {
        this.endDay = endDay;
    }

    public String getCurrentMentor() {
        return currentMentor;
    }


    public List<String> getInternships() {
        return internships;
    }

    public void setInternships(String internships) {
        this.internships = Arrays.asList(internships);
    }

    public String getCandiDateType() {
        return candiDateType;
    }

    public void setCandiDateType(String candiDateType) {
        this.candiDateType = candiDateType;
    }

    public String getProfileName() {
        return profileName;
    }

    public void setProfileName(String profileName) {
        this.profileName = profileName;
    }

    public String getSocialAccountId() {
        return socialAccountId;
    }

    public void setSocialAccountId(String socialAccountId) {
        this.socialAccountId = socialAccountId;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getFriendReferralCode() {
        return friendReferralCode;
    }

    public void setFriendReferralCode(String friendReferralCode) {
        this.friendReferralCode = friendReferralCode;
    }

    public String getShowPrimaryEmailOnPublicProfile() {
        return showPrimaryEmailOnPublicProfile;
    }

    public void setShowPrimaryEmailOnPublicProfile(String showPrimaryEmailOnPublicProfile) {
        this.showPrimaryEmailOnPublicProfile = showPrimaryEmailOnPublicProfile;
    }

    public String getShowContactNoOnPublicProfile() {
        return showContactNoOnPublicProfile;
    }

    public void setShowContactNoOnPublicProfile(String showContactNoOnPublicProfile) {
        this.showContactNoOnPublicProfile = showContactNoOnPublicProfile;
    }

    public String getShowZipCodeOnPublicProfile() {
        return showZipCodeOnPublicProfile;
    }

    public void setShowZipCodeOnPublicProfile(String showZipCodeOnPublicProfile) {
        this.showZipCodeOnPublicProfile = showZipCodeOnPublicProfile;
    }

    public String getShowUniversityOnPublicProfile() {
        return showUniversityOnPublicProfile;
    }

    public void setShowUniversityOnPublicProfile(String showUniversityOnPublicProfile) {
        this.showUniversityOnPublicProfile = showUniversityOnPublicProfile;
    }

    public String getShowDegreeOnPublicProfile() {
        return showDegreeOnPublicProfile;
    }

    public void setShowDegreeOnPublicProfile(String showDegreeOnPublicProfile) {
        this.showDegreeOnPublicProfile = showDegreeOnPublicProfile;
    }

    public String getShowMajorOnPublicProfile() {
        return showMajorOnPublicProfile;
    }

    public void setShowMajorOnPublicProfile(String showMajorOnPublicProfile) {
        this.showMajorOnPublicProfile = showMajorOnPublicProfile;
    }

    public String getShowGraduationDateOnPublicProfile() {
        return showGraduationDateOnPublicProfile;
    }

    public void setShowGraduationDateOnPublicProfile(String showGraduationDateOnPublicProfile) {
        this.showGraduationDateOnPublicProfile = showGraduationDateOnPublicProfile;
    }

    public String getShowVeteran() {
        return showVeteran;
    }

    public void setShowVeteran(String showVeteran) {
        this.showVeteran = showVeteran;
    }

    public String getVeteranBranch() {
        return veteranBranch;
    }

    public void setVeteranBranch(String veteranBranch) {
        this.veteranBranch = veteranBranch;
    }

    public String getMilitrayStatus() {
        return militrayStatus;
    }

    public void setMilitrayStatus(String militrayStatus) {
        this.militrayStatus = militrayStatus;
    }

    public String getOtherStatus() {
        return otherStatus;
    }

    public void setOtherStatus(String otherStatus) {
        this.otherStatus = otherStatus;
    }

    public String getOtherUniversity() {
        return otherUniversity;
    }

    public void setOtherUniversity(String otherUniversity) {
        this.otherUniversity = otherUniversity;
    }

    public String getVeteranClearance() {
        return veteranClearance;
    }

    public void setVeteranClearance(String veteranClearance) {
        this.veteranClearance = veteranClearance;
    }

    public String getUserAccessLocation() {
        return userAccessLocation;
    }

    public void setUserAccessLocation(String userAccessLocation) {
        this.userAccessLocation = userAccessLocation;
    }

    public String getTimeZone() {
        return timeZone;
    }

    public void setTimeZone(String timeZone) {
        this.timeZone = timeZone;
    }

    public String getIsTimeZoneUpDated() {
        return isTimeZoneUpDated;
    }

    public void setIsTimeZoneUpDated(String isTimeZoneUpDated) {
        this.isTimeZoneUpDated = isTimeZoneUpDated;
    }

    public String getIsSocialLogin() {
        return isSocialLogin;
    }

    public void setIsSocialLogin(String isSocialLogin) {
        this.isSocialLogin = isSocialLogin;
    }


    public LocalDateTime getSignedupOn() {
        return signedupOn;
    }

    public void setSignedupOn(String signedupOn) {
        LocalDateTime signedupon1=DateTimeFormat.forPattern("dd-MM-yyyy hh:mm:ss a").parseLocalDateTime(signedupOn);
        this.signedupOn = signedupon1;
    }

    public LocalDateTime getStartDate() {
        return startDate;
    }

    public void setStartDate( String startDate) {
        if(startDate!="null") {
            LocalDateTime startDate1 = DateTimeFormat.forPattern("dd-MM-yyyy hh:mm:ss a").parseLocalDateTime(startDate);

            this.startDate = startDate1;
        }
        else
            this.startDate=null;
    }

    public LocalDateTime getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        if(endDate!="null") {
            LocalDateTime endDate1 = DateTimeFormat.forPattern("dd-MM-yyyy hh:mm:ss a").parseLocalDateTime(endDate);
            this.endDate = endDate1;
        }
        else
            this.endDate=null;
    }

    public LocalDateTime getActivatedOn() {
        return activatedOn;
    }

    public void setActivatedOn(String activatedOn) {
        LocalDateTime activatedOn1=DateTimeFormat.forPattern("dd-MM-yyyy hh:mm:ss a").parseLocalDateTime(activatedOn);
        this.activatedOn = activatedOn1;
    }

    public LocalDateTime getLastLoggedTime() {
        return lastLoggedTime;
    }

    public void setLastLoggedTime(String lastLoggedTime) {
        LocalDateTime lastLoggedTime1= DateTimeFormat.forPattern("dd-MM-yyyy hh:mm:ss a").parseLocalDateTime(lastLoggedTime);
        this.lastLoggedTime = lastLoggedTime1;
    }

    public LocalDateTime getCurrentLoggedTime() {
        return currentLoggedTime;
    }

    public void setCurrentLoggedTime(String currentLoggedTime) {
        LocalDateTime currentLoggedTime1=DateTimeFormat.forPattern("dd-MM-yyyy hh:mm:ss a").parseLocalDateTime(currentLoggedTime);
        this.currentLoggedTime = currentLoggedTime1;
    }

    public LocalDateTime getGraduationDate() {
        return graduationDate;
    }

    public void setGraduationDate(String graduationDate) {
        if (graduationDate != "null" && graduationDate!=null) {
            LocalDateTime graduationDate1 = DateTimeFormat.forPattern("dd-MM-yyyy hh:mm:ss a").parseLocalDateTime(graduationDate);
            this.graduationDate = graduationDate1;
        }
    }

    public void setCurrentMentor(String currentMentor) {
        if(currentMentor!="null")
        this.currentMentor = currentMentor;
        else
            this.currentMentor=null;
    }

    public LocalDateTime getProfileUpDateTime() {
        return profileUpDateTime;
    }

        public void setProfileUpDateTime(String profileUpDateTime) {
        if(profileUpDateTime!="null"){
        LocalDateTime profileUpDateTime1=DateTimeFormat.forPattern("dd-MM-yyyy hh:mm a").parseLocalDateTime(profileUpDateTime);
        this.profileUpDateTime = profileUpDateTime1;}
        else
            this.profileUpDateTime=null;
    }

    public LocalDateTime getProfileUpDatedTime() {
        return profileUpDatedTime;
    }

    public void setProfileUpDatedTime(String profileUpDatedTime) {
        if(profileUpDatedTime!="null"){
        LocalDateTime profileUpDatedTime1=DateTimeFormat.forPattern("dd-MM-yyyy hh:mm:ss a").parseLocalDateTime(profileUpDatedTime);

        this.profileUpDatedTime = profileUpDatedTime1;}
        else
            this.profileUpDatedTime=null;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }





    public String getOtherSourceOfEntry() {
        return otherSourceOfEntry;
    }

    public void setOtherSourceOfEntry(String otherSourceOfEntry) {
        this.otherSourceOfEntry = otherSourceOfEntry;
    }

    public String getShortName() {
        return shortName;
    }

    public void setShortName(String shortName) {
        this.shortName = shortName;
    }

    public String getAcademicName() {
        return academicName;
    }

    public void setAcademicName(String academicName) {
        this.academicName = academicName;
    }

    public String getIsPayableCandiDate() {
        return isPayableCandiDate;
    }

    public void setIsPayableCandiDate(String isPayableCandiDate) {
        this.isPayableCandiDate = isPayableCandiDate;
    }

    public String getPlanExpiresOn() {
        return planExpiresOn;
    }

    public void setPlanExpiresOn(String planExpiresOn) {
      if(planExpiresOn!="null")
          this.planExpiresOn = planExpiresOn;
      else
          this.planExpiresOn=null;
    }

    public String getIsInternUpDate() {
        return isInternUpDate;
    }

    public void setIsInternUpDate(String isInternUpDate) {
        this.isInternUpDate = isInternUpDate;
    }

    public String getShowCurrentCityOnPublicProfile() {
        return showCurrentCityOnPublicProfile;
    }

    public void setShowCurrentCityOnPublicProfile(String showCurrentCityOnPublicProfile) {
        this.showCurrentCityOnPublicProfile = showCurrentCityOnPublicProfile;
    }

    public String getShowCurrentStateOnPublicProfile() {
        return showCurrentStateOnPublicProfile;
    }

    public void setShowCurrentStateOnPublicProfile(String showCurrentStateOnPublicProfile) {
        this.showCurrentStateOnPublicProfile = showCurrentStateOnPublicProfile;
    }
}