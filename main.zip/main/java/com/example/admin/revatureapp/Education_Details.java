package com.example.admin.revatureapp;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.support.v7.widget.Toolbar;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Space;
import android.widget.Spinner;
import android.widget.TextView;

import android.view.MenuItem;
import android.widget.Toast;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.methods.HttpPut;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.joda.time.DateTime;
import org.joda.time.LocalDateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Calendar;

public class Education_Details extends AppCompatActivity implements AdapterView.OnItemSelectedListener, NavigationView.OnNavigationItemSelectedListener{
    ProfileDetails details = new ProfileDetails();
    String id, stateId, stateName, stateCode, tempEmail, otherDegree, isActive, univId, univName, activationKey, isDeleted, isDeletedOn, workAuthorization, desiredPay, preferedCareerPath, sourceOfEntry, considerForEmployment, resetPasswordkey, internType, tmpPassword, traineeProjectCount, checkBox, gplusId, fbId, firstName, lastName, sendKey, minor, accountId, userId, resumeSource, campus, major_Name, address, dob, photo, photoType, profilePublish,  state, city, currentCity, collegeCity, collegeState, zip, marketReady, aboutMe, designation, profileScore, profileCompPercentage, degreeId, degreeName, passedoutYear, passedoutMonth, isContactNoUpdated, interest, type, otherMajor, referralCode, tempPassword, majorId, majorName, isLoggedIn, isOptOutDashboard, salesforceTrainingStatus, sfTrainingStatusUpdatedOn, isProfieAssessmentCompleted, password, securityToken, oldPassword, imageUrl, startDay, endDay, currentMentor, internships, candidateType, otherUniversity, socialAccountId, accountName, friendReferralCode, showPrimaryEmailOnPublicProfile, showContactNoOnPublicProfile, showCurrentCityOnPublicProfile, showCurrentStateOnPublicProfile, showZipCodeOnPublicProfile, showUniversityOnPublicProfile, showDegreeOnPublicProfile, showMajorOnPublicProfile, showGraduationDateOnPublicProfile, showVeteran, veteranBranch, militrayStatus, otherStatus, veteranClearance, userAccessLocation, timeZone, isTimeZoneUpdated, isSocialLogin, otherSourceOfEntry, shortName, academicName, isPayableCandidate, planExpiresOn, isInternUpdate;
    String activatedOn, currentLoggedTime, endDate, startDate, graduationDate, lastLoggedTime, signedupOn, profileUpdateTime, profileUpdatedTime;
    String activatedOn1, currentLoggedTime1, graduationDate1, signedupOn1, lastLoggedTime1;
    String univ_name, current_degree, major, gradDate,profile_Nam,mobile_Num;
    JSONObject json_countr;
    ImageView imageview1, imageview2, imageview3;
    Button button;
    Space space,space1;
  String countryId,countryName,countryDescription,countryCode;
    DrawerLayout drawer;
    NavigationView navigationView;
    TextView emailid,name,othermajor,otherdegree,majorask,degreeask;
    String full_Name, profile_Name, primary_Email, secondary_Email,email, coun_try, time_zone, zip_Code, current_State;
    String mobile_Number;
    JSONObject json_country,json_country1, json_degree, json_univ, json_major, json_state;
    String jsonCountry, jsonDegree, jsonMajor, jsonState, jsonUniv, result;
    Login login;
    InputStream inputStream = null;
    EditText currentDeg, majordept;
    AutoCompleteTextView universityName;
    TextView date;
    JSONObject json;
    CardView cardview,cardview1;
    DatePickerDialog datePickerDialog;
    ImageView profileImage;
EditText text,text1;
    String monthname;
    int mYear, mMonth, mDay;
int pos=0;
    Spinner spin;
    Spinner spinner;
Context context;
    public static String theMonth(int month) {
        String[] monthNames = {"January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"};
        return monthNames[month];
    }

    private static String convertInputStreamToString(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String line = "";
        StringBuilder result = new StringBuilder();
        while ((line = bufferedReader.readLine()) != null)
            result.append(line);

        inputStream.close();
        System.out.println("InputStream:" + result.toString());

        return result.toString();

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_education__details);
        context=getApplicationContext();
        date = (TextView) findViewById(R.id.date);
        othermajor=(TextView)findViewById(R.id.Othermajor);
        otherdegree=(TextView)findViewById(R.id.otherlabel);

        universityName= (AutoCompleteTextView)findViewById(R.id.schoolname);
        String[] college=getResources().getStringArray(R.array.USACollegeNames);
        ArrayAdapter<String> adapter2= new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,college);
        universityName.setAdapter(adapter2);
text=(EditText)findViewById(R.id.other);
text1=(EditText)findViewById(R.id.other1);
space=(Space)findViewById(R.id.space);
space1=(Space)findViewById(R.id.space1);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
 myToolbar.setNavigationOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                drawer.openDrawer(Gravity.LEFT);
            }
        });
        drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        text=(EditText)findViewById(R.id.other);
        cardview=(CardView)findViewById(R.id.card_view);
        cardview1=(CardView)findViewById(R.id.card_view5);
        navigationView = (NavigationView) findViewById(R.id.nav_view);
        name = (TextView) navigationView.getHeaderView(0).findViewById(R.id.profileName);
        emailid = (TextView) navigationView.getHeaderView(0).findViewById(R.id.emailId);
        profileImage = (ImageView) navigationView.getHeaderView(0).findViewById(R.id.profileImage);

        navigationView.setNavigationItemSelectedListener(this);
        imageview1=(ImageView)findViewById(R.id.imageButton1);
        imageview2=(ImageView)findViewById(R.id.imageButton2);
        imageview3=(ImageView)findViewById(R.id.imageButton3);
        majorask=(TextView)findViewById(R.id.Othermajorasterisk);
        degreeask=(TextView)findViewById(R.id.degreeasterisjk);
         spin = (Spinner) findViewById(R.id.major_spinner);
         spinner = (Spinner) findViewById(R.id.degree_spinner);


        new Image().execute();

        login = (Login) getIntent().getSerializableExtra("log");
        try {
            String json1=DashboardActivity.getDefaults("json",context);
            json = new JSONObject(json1);
            System.out.println(json.toString());
            JSONObject array = json;
            email=array.getString("email");
            profile_Name=array.getString("profileName");
            id = array.getString("id");
            tempEmail = array.getString("tempEmail");
            otherDegree = array.getString("otherDegree");
            if(otherDegree!=null & otherDegree!="null")
            {
                text.setText(otherDegree);
            }
            isActive = array.getString("isActive");
            gradDate=array.getString("graduationDate");
            if(gradDate!=null & gradDate!="null")
            gradDate=gradDate.substring(0,10);
            if(gradDate!=null & gradDate!="null")
            {
                gradDate=gradDate.substring(0,10);
                date.setText(gradDate);
            }
            signedupOn = array.getString("signedupOn");
            startDate = array.getString("startDate");
            details.setStartDate(startDate);
            endDate = array.getString("endDate");

            details.setEndDate(endDate);
            full_Name = array.getString("fullName");
            name.setText(full_Name);

            profile_Name = array.getString("profileName");
            System.out.println("pr"+profile_Name);

            primary_Email = array.getString("email");
            secondary_Email = array.getString("secondaryEmail");
            time_zone = array.getString("timeZone");
            zip_Code = array.getString("zip");
            current_State = array.getString("currentState");
mobile_Number=array.getString("contactNo");

            activationKey = array.getString("activationKey");
            isDeleted = array.getString("isDeleted");
            isDeletedOn = array.getString("isDeletedOn");
            workAuthorization = array.getString("workAuthorization");
            desiredPay = array.getString("desiredPay");
            preferedCareerPath = array.getString("preferedCareerPath");
            sourceOfEntry = array.getString("sourceOfEntry");
            considerForEmployment = array.getString("considerForEmployment");
            resetPasswordkey = array.getString("resetPasswordKey");
            internType = array.getString("internType");
            tmpPassword = array.getString("tmpPassword");
            traineeProjectCount = array.getString("traineeProjectCount");
            checkBox = array.getString("checkBox");
            gplusId = array.getString("gplusId");
            fbId = array.getString("fbId");
            firstName = array.getString("firstName");

            lastName = array.getString("lastName");
            sendKey = array.getString("sendKey");
            minor = array.getString("minor");
            accountId = array.getString("accountId");
            userId = array.getString("userId");
            resumeSource = array.getString("resumeSource");
            campus = array.getString("campus");
            address = array.getString("address");
            dob = array.getString("dob");
            photo = array.getString("photo");
            photoType = array.getString("photoType");
            profilePublish = array.getString("profilePublish");
            collegeCity = array.getString("collegeCity");
            collegeState = array.getString("collegeState");

            state = array.getString("state");
            city = array.getString("city");
            currentCity = array.getString("currentCity");
            zip = array.getString("zip");
            marketReady = array.getString("marketReady");
            aboutMe = array.getString("aboutMe");
            designation = array.getString("designation");
            activatedOn = array.getString("activatedOn");
            System.out.println("ACTIVATEDON:" + activatedOn);
            lastLoggedTime = array.getString("lastLoggedTime");

            currentLoggedTime = array.getString("currentLoggedTime");

            profileScore = array.getString("profileScore");
            profileCompPercentage = array.getString("profileCompPercentage");

            isContactNoUpdated = array.getString("isContactNoUpdated");
            interest = array.getString("interest");
            type = array.getString("type");

            otherMajor = array.getString("otherMajor");
            if(otherMajor!=null && otherMajor!="null")
            {
                text1.setText(otherMajor);
            }
            referralCode = array.getString("referralCode");
            tempPassword = array.getString("tempPassword");
            majorName = array.getString("majorName");
            isLoggedIn = array.getString("isLoggedIn");
            isOptOutDashboard = array.getString("isOptOutDashboard");
            salesforceTrainingStatus = array.getString("salesforceTrainingStatus");
            sfTrainingStatusUpdatedOn = array.getString("sfTrainingStatusUpdatedOn");
            isProfieAssessmentCompleted = array.getString("isProfieAssessmentCompleted");
            password = array.getString("password");

            securityToken = array.getString("securityToken");
            oldPassword = array.getString("oldPassword");
            imageUrl = array.getString("imageUrl");
            startDay = array.getString("startDay");
            endDay = array.getString("endDay");
            currentMentor = array.getString("currentMentor");
            System.out.println("MENTOR" + currentMentor);
            profileUpdateTime = getCurrentLocalDateTimeStamp();

            details.setProfileUpDateTime(profileUpdateTime);
            System.out.println("PROFILE" + details.getProfileUpDateTime());

            internships = array.getString("internships");
            candidateType = array.getString("candidateType");
            socialAccountId = array.getString("socialAccountId");
            accountName = array.getString("accountName");
            friendReferralCode = array.getString("friendReferralCode");
            showPrimaryEmailOnPublicProfile = array.getString("showPrimaryEmailOnPublicProfile");
            showContactNoOnPublicProfile = array.getString("showContactNoOnPublicProfile");
            showCurrentCityOnPublicProfile = array.getString("showCurrentCityOnPublicProfile");
            showCurrentStateOnPublicProfile = array.getString("showCurrentStateOnPublicProfile");
            showZipCodeOnPublicProfile = array.getString("showZipCodeOnPublicProfile");
            showUniversityOnPublicProfile = array.getString("showUniversityOnPublicProfile");
            showDegreeOnPublicProfile = array.getString("showDegreeOnPublicProfile");
            showMajorOnPublicProfile = array.getString("showMajorOnPublicProfile");
            showGraduationDateOnPublicProfile = array.getString("showGraduationDateOnPublicProfile");
            showVeteran = array.getString("showVeteran");
            veteranBranch = array.getString("veteranBranch");
            militrayStatus = array.getString("militrayStatus");
            otherStatus = array.getString("otherStatus");
            otherUniversity = array.getString("otherUniversity");
            veteranClearance = array.getString("veteranClearance");
            userAccessLocation = array.getString("userAccessLocation");
            timeZone = array.getString("timeZone");
            isTimeZoneUpdated = array.getString("isTimeZoneUpdated");
            isSocialLogin = array.getString("isSocialLogin");
            profileUpdatedTime = array.getString("profileUpdatedTime");

            details.setProfileUpDatedTime(profileUpdatedTime);


            otherSourceOfEntry = array.getString("otherSourceOfEntry");
            shortName = array.getString("shortName");
            academicName = array.getString("academicName");
            isPayableCandidate = array.getString("isPayableCandidate");
            planExpiresOn = array.getString("planExpiresOn");
            isInternUpdate = array.getString("isInternUpdate");
            JSONObject countryobj = array.getJSONObject("country");

            countryId=countryobj.getString("id");
            details.setCountryId(countryId);
            countryName=countryobj.getString("name");
            if(countryName.equals("USA"))
            {
                String[] college1=getResources().getStringArray(R.array.USACollegeNames);
                ArrayAdapter<String> adapter3= new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,college1);
                universityName.setAdapter(adapter3);
            }
            else {
                String[] college1=getResources().getStringArray(R.array.CollegeNames);
                ArrayAdapter<String> adapter3= new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,college1);
                universityName.setAdapter(adapter3);
            }
            details.setCountryName(countryName);

            countryCode=countryobj.getString("code");
            details.setCountryCode(countryCode);


            countryDescription=countryobj.getString("description");

            JSONObject majorobj = array.getJSONObject("major");

            JSONObject internobj = array.getJSONObject("university");
          //  JSONObject univobj = internobj.getJSONObject("state");
         //   JSONObject stateobj = univobj.getJSONObject("country");
            JSONObject degobj = array.getJSONObject("degrees");
            degreeId=degobj.getString("id");
            degreeName=degobj.getString("name");
            System.out.println("degr"+degreeName);
            majorId=majorobj.getString("id");
            major=majorobj.getString("name");
            univId = internobj.getString("id");
            univName=internobj.getString("name");
            if(univName!=null && univName!="null")

            {
                int id=0;
                String univ[]=getResources().getStringArray(R.array.CollegeNames);
                for(int i=0;i<univ.length;i++) {
                    univName.equals(univ[i]);
                    {
                        id=i;
                    }
                }
                universityName.setText(univName);
                univId=Integer.toString(id);
                details.setUnivId(univId);


            }


            majorId = majorobj.getString("id");

//            stateId = univobj.getString("id");
//            stateName = univobj.getString("name");
//            stateCode = univobj.getString("code");


        } catch (Exception e) {
            e.printStackTrace();
        }

        date.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // calender class's instance and get current date , month and year from calender
                final Calendar c = Calendar.getInstance();
                mYear = c.get(Calendar.YEAR); // current year
                mMonth = c.get(Calendar.MONTH); // current month
                mDay = c.get(Calendar.DAY_OF_MONTH); // current day
                // date picker dialog
                datePickerDialog = new DatePickerDialog(Education_Details.this,
                        new DatePickerDialog.OnDateSetListener() {

                            @Override
                            public void onDateSet(DatePicker view, int year,
                                                  int monthOfYear, int dayOfMonth) {
                                // set day of month , month and year value in the edit text
                                date.setText(dayOfMonth + "-"
                                        + (monthOfYear + 1) + "-" + year);

                            }
                        }, mYear, mMonth, mDay);
                datePickerDialog.show();
            }
        });


        button = (Button) findViewById(R.id.updatebutton);



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (universityName.getText().length() == 0) {
                    universityName.setError("University Name cannot be blank ");
                }
                else  if (spin.getSelectedItemPosition() == 0) {
                    Toast.makeText(getBaseContext(), "Select Major", Toast.LENGTH_LONG).show();
                } else if(spinner.getSelectedItemPosition() == 0)
                {
                    Toast.makeText(getBaseContext(), "Select Degree", Toast.LENGTH_LONG).show();

                }
                else if (date.getText().length() == 0) {
                    date.setError("Invalid Date ");
                } else {
                    new EducationDetails().execute();
                }
            }
        });


        imageview1.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Education_Details.this, Profile.class);
                intent.putExtra("Login_object",login);
                intent.putExtra("Json_obj",json.toString());
                startActivity(intent);

            }

        });



        imageview3.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent intent = new Intent(Education_Details.this, Change_Password.class);
                intent.putExtra("Log_object",login);
                intent.putExtra("Json_obj",json.toString());

                startActivity(intent);

            }

        });
        ArrayAdapter<CharSequence> adapter1 = ArrayAdapter.createFromResource(this,
                R.array.Major, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter1.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spin.setAdapter(adapter1);
       spin.setSelection(pos);

        spin.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
      major = parent.getItemAtPosition(position).toString();
      System.out.println("major"+major);
        if(major.equals("Other")){
            othermajor.setVisibility(View.VISIBLE);
            majorask.setVisibility(View.VISIBLE);
            text1.setVisibility(View.VISIBLE);
            cardview1.setVisibility(View.VISIBLE);
            space.setVisibility(View.VISIBLE);
        }

        else{
            othermajor.setVisibility(View.GONE);
            majorask.setVisibility(View.GONE);
            text1.setVisibility(View.GONE);
            cardview1.setVisibility(View.GONE);
            space.setVisibility(View.GONE);
        }
        otherMajor=text.getText().toString();
        majorId=Long.toString(id);
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
});
        if(major!=null)
        {
            System.out.println("major"+major);
//            int id=0;
//             String major[]=getResources().getStringArray(R.array.Major);
//             for(int i=0;i<major.length;i++)
//             {
//                 if(major.equals(major[i]))
//                 {
//                     id=i;
//                     break;
//                 }
//             }
            spin.setSelection(adapter1.getPosition(major));
        }

        spinner.setOnItemSelectedListener(this);

// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.CurrentDegree, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);
spinner.setSelection(pos);
        if(degreeName!=null)
        {
//            int id=0;
//System.out.println("yesiamdegree");
//            String degree[]=getResources().getStringArray(R.array.CurrentDegree);
//            for(int i=0;i<degree.length;i++)
//            {
//               if(degree.equals(degree[i]))
//               {
//                   id=i;
//                   break;
//
//               }
//            }
            spinner.setSelection(adapter.getPosition(degreeName));

        }
    }

    public void onItemSelected(AdapterView<?> parent, View view,
                               int pos, long id) {
        // An item was selected. You can retrieve the selected item using
        // parent.getItemAtPosition(pos)
       current_degree = parent.getItemAtPosition(pos).toString();
       if(current_degree.equals("Other")){
           text.setVisibility(View.VISIBLE);
           otherdegree.setVisibility(View.VISIBLE);
           degreeask.setVisibility(View.VISIBLE);
           cardview.setVisibility(View.VISIBLE);
       space1.setVisibility(View.VISIBLE);}

       else{
           text.setVisibility(View.GONE);
           degreeask.setVisibility(View.GONE);
           otherdegree.setVisibility(View.GONE);
         cardview.setVisibility(View.GONE);
       space1.setVisibility(View.GONE);}
       otherDegree=text.getText().toString();
       degreeId=Long.toString(id);

    }

    public void onNothingSelected(AdapterView<?> parent) {
        // Another interface callback
    }
    public String getCorrectActivatedDate() {
        LocalDateTime dateTime = details.getActivatedOn();
        System.out.println(dateTime);

        DateTimeFormatter dtf = DateTimeFormat.forPattern("dd-MM-yyyy hh:mm:ss a");
        System.out.println("correct:" + dtf.print(dateTime));
        String correctDateTime = dtf.print(dateTime).toString();
        return correctDateTime;

    }

    public String getCorrectLastLoggedTime() {
        LocalDateTime dateTime = details.getLastLoggedTime();
        System.out.println(dateTime);

        DateTimeFormatter dtf = DateTimeFormat.forPattern("dd-MM-yyyy hh:mm:ss a");
        System.out.println("correct:" + dtf.print(dateTime));
        String correctDateTime = dtf.print(dateTime).toString();
        return correctDateTime;

    }

    public String getCorrectCurrentLoggedTime() {
        LocalDateTime dateTime = details.getCurrentLoggedTime();
        System.out.println(dateTime);

        DateTimeFormatter dtf = DateTimeFormat.forPattern("dd-MM-yyyy hh:mm:ss a");
        System.out.println("correct:" + dtf.print(dateTime));
        String correctDateTime = dtf.print(dateTime).toString();
        return correctDateTime;

    }

    public String getCorrectGraduationDate() {
        LocalDateTime dateTime = details.getGraduationDate();
        System.out.println(dateTime);

        DateTimeFormatter dtf = DateTimeFormat.forPattern("dd-MM-yyyy");
        System.out.println("correct:" + dtf.print(dateTime));
        String correctDateTime = dtf.print(dateTime).toString();
        return correctDateTime;

    }

    public String getCorrectSignedUpOn() {
        LocalDateTime dateTime = details.getCurrentLoggedTime();
        System.out.println(dateTime);

        DateTimeFormatter dtf = DateTimeFormat.forPattern("dd-MM-yyyy hh:mm:ss a");
        System.out.println("correct:" + dtf.print(dateTime));
        String correctDateTime = dtf.print(dateTime).toString();
        return correctDateTime;

    }

    public String getCurrentLocalDateTimeStamp() {
        DateTime dateTime = new DateTime();
        System.out.println(dateTime);

        DateTimeFormatter dtf = DateTimeFormat.forPattern("dd-MM-yyyy hh:mm a");
        System.out.println(dtf.print(dateTime));
        String currentDateTime = dtf.print(dateTime).toString();
        return currentDateTime;

    }
    public boolean onNavigationItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.dashboard) {
            Intent intent = new Intent(this,DashboardActivity.class);
            intent.putExtra("Login_Class",login);
            intent.putExtra("JSON_RESPONSE",json.toString());
            startActivity(intent);
        } else if (id == R.id.quizzes) {
            Intent intent = new Intent(this,MyActivity.class);
            intent.putExtra("Login",login);
            intent.putExtra("JSON_RESPONSE",json.toString());

            startActivity(intent);
        }else if (id == R.id.profile){
            Intent intent = new Intent(this,Profile.class);
            intent.putExtra("Login_object",login);

            intent.putExtra("Json_obj",json.toString());

            startActivity(intent);
        }else if (id == R.id.logout){
            new android.app.AlertDialog.Builder(this).setIcon(android.R.drawable.ic_dialog_alert).setTitle("Signout")
                    .setMessage("Are you sure?")
                    .setPositiveButton("yes", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            new Logout().execute();

                        }
                    }).setNegativeButton("no", null).show();

        }

        item.setChecked(true);
        // close drawer when item is tapped
        drawer.closeDrawers();
        return true;
    }
    class Image extends AsyncTask<String,String,String>
    {
        InputStream inputStream=null;
        String result;
        @Override
        protected void onPostExecute(String s) {
            try
            {
                JSONObject myObject = new JSONObject(result);
                String statusCode = myObject.getString("statusCode");
                String image=myObject.getString("data");
                new DownLoadImageTask(profileImage).execute(image);



            }catch(Exception e)
            {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(String... strings) {
            try
            {
                HttpGet get= new HttpGet("https://qa2.revature.com/core/resources/secure/interns/image");
                get.setHeader("Authorization",login.getToken());
                get.setHeader("Accept","application/json");
                HttpClient client = new DefaultHttpClient();
                HttpResponse response = client.execute(get);
                inputStream = response.getEntity().getContent();
                if (inputStream != null){
                    result = convertInputStreamToString(inputStream);
                }
                else
                    result = "Did not work!";
                return null;
            }catch (Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }
    }
    private class DownLoadImageTask extends AsyncTask<String,Void,Bitmap>{
        ImageView imageView;

        public DownLoadImageTask(ImageView imageView){
            this.imageView = imageView;
        }

        /*
            doInBackground(Params... params)
                Override this method to perform a computation on a background thread.
         */
        protected Bitmap doInBackground(String...urls){
            String urlOfImage = urls[0];
            Bitmap logo = null;
            try{
                InputStream is = new URL(urlOfImage).openStream();
                /*
                    decodeStream(InputStream is)
                        Decode an input stream into a bitmap.
                 */
                logo = BitmapFactory.decodeStream(is);
            }catch(Exception e){ // Catch the download exception
                e.printStackTrace();
            }
            return logo;
        }

        /*
            onPostExecute(Result result)
                Runs on the UI thread after doInBackground(Params...).
         */
        protected void onPostExecute(Bitmap result){
            imageView.setImageBitmap(result);
        }
    }
    class Logout extends AsyncTask<String,String,String>
    {
        ProgressDialog progress;
        @Override
        protected void onPreExecute() {
            progress=new ProgressDialog(Education_Details.this);
            progress.setMessage("Processing your logout request");
            progress.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            progress.setIndeterminate(true);
            progress.show();        }

        @Override
        protected void onPostExecute(String s) {
            try
            {
                JSONObject json = new JSONObject(result);
                progress.cancel();
                String statusCode=json.getString("statusCode");
                if(statusCode.equals("SC007"))
                {
                    Toast.makeText(getBaseContext(), "Logged out successfully ", Toast.LENGTH_LONG).show();
                    Intent intent = new Intent(Education_Details.this, MainActivity.class);
                    intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(intent);
                }
            }catch(Exception e)
            {
                e.printStackTrace();
            }
        }

        @Override
        protected String doInBackground(String... strings) {
            try{
                HttpPost post = new HttpPost("https://qa2.revature.com/core/resources/secure/interns/logout");
                post.setHeader("Accept","application/json");
                post.setHeader("Authorization",login.getToken());
                HttpClient httpclient = new DefaultHttpClient();
                HttpResponse res = httpclient.execute(post);

                inputStream = res.getEntity().getContent();


                if (inputStream != null) {
                    result = convertInputStreamToString(inputStream);
                } else {
                    result = "Did not work!";
                }

            }catch(Exception e)
            {
                e.printStackTrace();
            }
            return null;
        }
    }
    class EducationDetails extends AsyncTask<String, String, String> {
        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(String s) {
            try
            {
                JSONObject json = new JSONObject(result);
                String statusCode=json.getString("statusCode");
                String description=json.getString("description");
                if(statusCode.equals("SC007"))
                {
                    Toast.makeText(getBaseContext(), description, Toast.LENGTH_LONG).show();
                    JSONObject data= json.getJSONObject("data");
                    DashboardActivity.setDefaults("json",data.toString(),context);
                }
                else {
                    Toast.makeText(getBaseContext(), description, Toast.LENGTH_LONG).show();

                }
            }catch(Exception e)
            {
                e.printStackTrace();
            }        }

        @Override
        protected String doInBackground(String... strings) {
            univ_name = universityName.getText().toString();
            otherDegree=text.getText().toString();
            if(univ_name!=null)

            {
                int id=0;
                String univ[]=getResources().getStringArray(R.array.CollegeNames);
                for(int i=0;i<univ.length;i++) {
                    univ_name.equals(univ[i]);
                    {
                        id=i;
                        break;
                    }
                }
                univId=Integer.toString(id+1);
                details.setUnivId(univId);


            }
            gradDate = date.getText().toString();

            details.setFullName(full_Name);
            if(profile_Name==null) {
            }
            else
            details.setProfileName(profile_Name);
            details.setEmail(primary_Email);
            if(secondary_Email==null)
            {

            }
            else
                details.setSecondaryEmail(secondary_Email);
            if(mobile_Number!=null && mobile_Number!="null")
            {
                mobile_Number=mobile_Number.replace("-",mobile_Number.substring(4,mobile_Number.length()));
                mobile_Number=mobile_Number.replace("-",mobile_Number.substring(7,mobile_Number.length()));
                mobile_Number=mobile_Number.substring(0,10);
                mobile_Number = mobile_Number.substring(0, 3) + "-" + mobile_Number.substring(3, 6) + "-" + mobile_Number.substring(6, mobile_Number.length());

                System.out.println("mob"+mobile_Number);
            details.setContactNo(mobile_Number);}
            details.setTimeZone(time_zone);
            if (zip_Code == null)
            {

            }
            else
                details.setZip(zip_Code);
            if(current_State==null)
            {

            }
           else
               details.setCurrentState(current_State);
            details.setAboutMe(aboutMe);
            details.setAcademicName(academicName);
            details.setAccountId(accountId);
            details.setAccountName(accountName);
            details.setActivatedOn(activatedOn);
            details.setActivationKey(activationKey);
            details.setCampus(campus);
            details.setCandiDateType(candidateType);
            details.setAddress(address);
            details.setCheckBox(checkBox);
            details.setConsiderForEmployment(considerForEmployment);
            details.setCity(city);
            details.setCurrentCity(currentCity);
            details.setCurrentLoggedTime(currentLoggedTime);
            details.setCurrentMentor(currentMentor);
            details.setDegreeId(degreeId);
            details.setDegreeName(current_degree);
            details.setDesignation(designation);
            details.setDesiredPay(desiredPay);
            details.setDob(dob);
            details.setGraduationDate(gradDate+" "+"12:00:00 AM");
            details.setEndDay(endDay);
            details.setFbId(fbId);
            details.setFirstName(firstName);
            details.setFriendReferralCode(friendReferralCode);
            details.setGplusId(gplusId);
            details.setId(id);
            if (imageUrl == null)
                     {


            }
            else
                details.setImageUrl(imageUrl);
            details.setInterest(interest);
            details.setInternships(internships);
            details.setInternType(internType);
            details.setIsActive(isActive);
            details.setIsContactNoUpDated(isContactNoUpdated);
            details.setIsDeleted(isDeleted);
            details.setIsDeletedOn(isDeletedOn);
            details.setIsInternUpDate(isInternUpdate);
            details.setIsLoggedIn(isLoggedIn);
            details.setIsOptOutDashboard(isOptOutDashboard);
            details.setIsPayableCandiDate(isPayableCandidate);
            details.setIsProfieAssessmentCompleted(isProfieAssessmentCompleted);
            details.setIsSocialLogin(isSocialLogin);
            details.setIsContactNoUpDated(isContactNoUpdated);
            details.setShowContactNoOnPublicProfile(showContactNoOnPublicProfile);
            details.setIsContactNoUpDated(isContactNoUpdated);
            details.setIsTimeZoneUpDated(isTimeZoneUpdated);
            details.setLastLoggedTime(lastLoggedTime);
            details.setLastName(lastName);
            details.setMajor_Name(major);
            details.setMajorId(majorId);
            details.setMajorName(majorName);
            details.setMarketReady(marketReady);
            details.setMilitrayStatus(militrayStatus);
            details.setMinor(minor);
            details.setOldPassword(oldPassword);
            details.setOtherDegree(otherDegree);
            details.setOtherMajor(otherMajor);
            details.setOtherSourceOfEntry(otherSourceOfEntry);
            details.setOtherStatus(otherStatus);
            details.setPassedoutMonth(theMonth(mMonth));
            details.setWorkAuthorization(workAuthorization);
            details.setVeteranClearance(veteranClearance);
            details.setVeteranBranch(veteranBranch);
            details.setUserId(userId);
            details.setUserAccessLocation(userAccessLocation);
            details.setUnivName(univ_name);
            details.setUnivId(univId);
            details.setType(type);
            details.setTraineeProjectCount(traineeProjectCount);
            details.setTmpPassword(tmpPassword);
            details.setTempPassword(tempPassword);
            details.setTempEmail(tempEmail);
            details.setState(state);
            details.setStartDay(startDay);

            details.setSourceOfEntry(sourceOfEntry);
            details.setSocialAccountId(socialAccountId);
            details.setSignedupOn(signedupOn);
            details.setShowZipCodeOnPublicProfile(showZipCodeOnPublicProfile);
            details.setShowVeteran(showVeteran);
            details.setShowUniversityOnPublicProfile(showUniversityOnPublicProfile);
            details.setShowPrimaryEmailOnPublicProfile(showPrimaryEmailOnPublicProfile);
            details.setShowMajorOnPublicProfile(showMajorOnPublicProfile);
            details.setShowGraduationDateOnPublicProfile(showGraduationDateOnPublicProfile);
            details.setShowDegreeOnPublicProfile(showDegreeOnPublicProfile);
            details.setShowCurrentStateOnPublicProfile(showCurrentStateOnPublicProfile);
            details.setShowCurrentCityOnPublicProfile(showCurrentCityOnPublicProfile);
            details.setPassedoutYear(Integer.toString(mYear));
            details.setShortName(shortName);
            details.setSfTrainingStatusUpDatedOn(sfTrainingStatusUpdatedOn);

            details.setSendKey(sendKey);
            details.setSecurityToken(securityToken);
            details.setSalesforceTrainingStatus(salesforceTrainingStatus);
            details.setResumeSource(resumeSource);
            details.setResetPasswordkey(resetPasswordkey);
            details.setReferralCode(referralCode);


            details.setProfileScore(profileScore);
            details.setProfilePublish(profilePublish);
            details.setProfileCompPercentage(profileCompPercentage);
            details.setPreferedCareerPath(preferedCareerPath);
            details.setPlanExpiresOn(planExpiresOn);
            details.setPhotoType(photoType);
            details.setPhoto(photo);
            details.setPassword(password);
            details.setOtherUniversity(otherUniversity);
            details.setCollegeCity(collegeCity);
            details.setCollegeState(collegeState);
            details.setStateId(stateId);
            details.setStateName(stateName);
            details.setStateCode(stateCode);
            activatedOn1 = getCorrectActivatedDate();
            currentLoggedTime1 = getCorrectCurrentLoggedTime();
            graduationDate1 = getCorrectGraduationDate();
            signedupOn1 = getCorrectSignedUpOn();
            lastLoggedTime1 = getCorrectLastLoggedTime();
            try {
                json_country = new JSONObject();
                json_country.accumulate("id", details.getCountryId());
                json_country.accumulate("name", details.getCountryName());
                json_country.accumulate("code", details.getCountryCode());

                jsonCountry = json_country.toString();
                json_country1 = new JSONObject();
                json_country1.accumulate("id", details.getCountryId());
                json_country1.accumulate("name", details.getCountryName());
                json_country1.accumulate("code", details.getCountryCode());
                json_country1.accumulate("description", JSONObject.NULL);

                json_degree = new JSONObject();
                json_degree.accumulate("id", details.getDegreeId());
                json_degree.accumulate("name", details.getDegreeName());
                jsonDegree = json_degree.toString();
                json_major = new JSONObject();
                json_major.accumulate("id", details.getMajorId());
                json_major.accumulate("name", details.getMajor_Name());
                json_major.accumulate("isActive", details.getIsActive());
                jsonMajor = json_major.toString();
                json_state = new JSONObject();
                json_state.accumulate("id", details.getStateId());
                json_state.accumulate("name", details.getStateName());
                json_state.accumulate("isActive", details.getStateCode());
                json_state.accumulate("description", JSONObject.NULL);
                json_state.accumulate("country", json_country1);
                jsonState = json_state.toString();
                json_univ = new JSONObject();
                json_univ.accumulate("id", details.getUnivId());
                json_univ.accumulate("name", details.getUnivName());
                json_univ.accumulate("city", JSONObject.NULL);
                json_univ.accumulate("state", json_state);
                jsonUniv = json_univ.toString();
                System.out.println("JSONUNIV" + jsonUniv);
                jsonCountry = jsonCountry.replaceAll("\\\\", "");
                jsonDegree = jsonDegree.replaceAll("\\\\", "");
                jsonMajor = jsonMajor.replaceAll("\\\\", "");
                jsonUniv = jsonUniv.replaceAll("\\\\", "");
                jsonState = jsonState.replaceAll("\\\\", "");

                System.out.println("JSONUNIV" + jsonCountry);

                HttpPut put = new HttpPut("https://qa2.revature.com/core/resources/secure/interns");
                put.setHeader("Accept", "application/json");
                put.setHeader("content-Type", "application/json");
                put.setHeader("Authorization", login.getToken());
                JSONObject json = new JSONObject();
                json.accumulate("id", JSONObject.NULL);
                json.accumulate("email", details.getEmail());
                if(secondary_Email!=null && secondary_Email!="null" )

                    json.accumulate("secondaryEmail", details.getSecondaryEmail());
                else
                    json.accumulate("secondaryEmail", JSONObject.NULL);

                json.accumulate("tempEmail", JSONObject.NULL);
                json.accumulate("aboutMe", JSONObject.NULL);
                json.accumulate("academicName", JSONObject.NULL);
                json.accumulate("accountId", JSONObject.NULL);
                json.accumulate("accountName", JSONObject.NULL);
                json.accumulate("activatedOn", activatedOn1);
                json.accumulate("activationKey", JSONObject.NULL);
                json.accumulate("address", JSONObject.NULL);
                json.accumulate("campus", JSONObject.NULL);
                json.accumulate("candidateType", details.getCandiDateType());
                json.accumulate("checkBox", details.getCheckBox());
                json.accumulate("city", JSONObject.NULL);
              //  json.accumulate("collegeCity", JSONObject.NULL);
             //   json.accumulate("collegeState", JSONObject.NULL);
                json.accumulate("considerForEmployment", JSONObject.NULL);
                json.accumulate("contactNo", details.getContactNo());
                json.accumulate("currentCity", JSONObject.NULL);
                json.accumulate("currentLoggedTime", currentLoggedTime1);
                json.accumulate("currentMentor", JSONObject.NULL);
                if(current_State!=null && current_State!="null" )
                json.accumulate("currentState", details.getCurrentState());
                else
                    json.accumulate("currentState",JSONObject.NULL);

                json.accumulate("designation", JSONObject.NULL);
                json.accumulate("desiredPay", JSONObject.NULL);
                json.accumulate("dob", JSONObject.NULL);
                json.accumulate("endDate", JSONObject.NULL);
                json.accumulate("endDay", JSONObject.NULL);
                json.accumulate("fbId", JSONObject.NULL);
                json.accumulate("firstName", details.getFirstName());
                json.accumulate("friendReferralCode", JSONObject.NULL);
                json.accumulate("fullName", details.getFullName());
                json.accumulate("gplusId", JSONObject.NULL);
                json.accumulate("graduationDate", graduationDate1 +" "+"12:00:00 AM" );
                if(imageUrl!=null && imageUrl!="null")
                json.accumulate("imageUrl", details.getImageUrl());
                else
                    json.accumulate("imageUrl", JSONObject.NULL);

                json.accumulate("interest", JSONObject.NULL);
                json.accumulate("internType", details.getInternType());
                json.accumulate("internships", JSONObject.NULL);
                json.accumulate("isActive", details.getIsActive());
                json.accumulate("isContactNoUpdated", JSONObject.NULL);
                json.accumulate("isDeleted", details.getIsDeleted());
                json.accumulate("isDeletedOn", JSONObject.NULL);
                json.accumulate("isInternUpdate", JSONObject.NULL);
                json.accumulate("isLoggedIn", details.getIsLoggedIn());
                json.accumulate("isOptOutDashboard", JSONObject.NULL);
                json.accumulate("isPayableCandidate", JSONObject.NULL);
                json.accumulate("isProfieAssessmentCompleted", details.getIsProfieAssessmentCompleted());
                json.accumulate("isSocialLogin", details.getIsSocialLogin());
                json.accumulate("isTimeZoneUpdated", details.getIsTimeZoneUpDated());
                json.accumulate("lastLoggedTime", lastLoggedTime1);
                json.accumulate("lastName", details.getLastName());
                json.accumulate("majorName", JSONObject.NULL);
                json.accumulate("marketReady", JSONObject.NULL);
                json.accumulate("militrayStatus", JSONObject.NULL);
                json.accumulate("minor", JSONObject.NULL);
                json.accumulate("oldPassword", JSONObject.NULL);
                json.accumulate("otherDegree", details.getOtherDegree());
                json.accumulate("otherMajor", details.getOtherMajor());
                json.accumulate("otherSourceOfEntry", JSONObject.NULL);
                json.accumulate("otherStatus", JSONObject.NULL);
                json.accumulate("otherUniversity", JSONObject.NULL);
                json.accumulate("passedoutMonth", details.getPassedoutMonth());
                json.accumulate("passedoutYear", details.getPassedoutYear());
                json.accumulate("password", JSONObject.NULL);
                json.accumulate("photo", JSONObject.NULL);
                json.accumulate("photoType", JSONObject.NULL);
                json.accumulate("planExpiresOn", JSONObject.NULL);
                json.accumulate("preferedCareerPath", JSONObject.NULL);
                json.accumulate("profileCompPercentage", JSONObject.NULL);
                if(profile_Name!=null && profile_Name!="null" )
                    json.accumulate("profileName", details.getProfileName());

                else
                json.accumulate("profileName", JSONObject.NULL);

                json.accumulate("profilePublish", JSONObject.NULL);
                json.accumulate("profileScore", JSONObject.NULL);
                json.accumulate("profileUpdateTime", details.getProfileUpDateTime());
                json.accumulate("profileUpdatedTime", JSONObject.NULL);
                json.accumulate("referralCode", details.getReferralCode());
                json.accumulate("resetPasswordKey", JSONObject.NULL);
                json.accumulate("resumeSource", JSONObject.NULL);
                json.accumulate("salesforceTrainingStatus", JSONObject.NULL);
                json.accumulate("securityToken", JSONObject.NULL);
                json.accumulate("sendKey", JSONObject.NULL);
                json.accumulate("sfTrainingStatusUpdatedOn", JSONObject.NULL);
                json.accumulate("shortName", JSONObject.NULL);
                json.accumulate("showContactNoOnPublicProfile", details.getShowContactNoOnPublicProfile());
                json.accumulate("showCurrentCityOnPublicProfile", details.getShowCurrentCityOnPublicProfile());
                json.accumulate("showCurrentStateOnPublicProfile", details.getShowCurrentStateOnPublicProfile());
                json.accumulate("showDegreeOnPublicProfile", details.getShowDegreeOnPublicProfile());
                json.accumulate("showGraduationDateOnPublicProfile", details.getShowGraduationDateOnPublicProfile());
                json.accumulate("showMajorOnPublicProfile", details.getShowMajorOnPublicProfile());
                json.accumulate("showPrimaryEmailOnPublicProfile", details.getShowPrimaryEmailOnPublicProfile());
                json.accumulate("showUniversityOnPublicProfile", details.getShowUniversityOnPublicProfile());
                json.accumulate("showVeteran", details.getShowVeteran());
                json.accumulate("showZipCodeOnPublicProfile", details.getShowZipCodeOnPublicProfile());
                json.accumulate("signedupOn", signedupOn1);
                json.accumulate("socialAccountId", JSONObject.NULL);
                json.accumulate("sourceOfEntry", JSONObject.NULL);
                json.accumulate("startDate", JSONObject.NULL);
                json.accumulate("startDay", JSONObject.NULL);
                json.accumulate("state", JSONObject.NULL);
                json.accumulate("tempPassword", JSONObject.NULL);
                json.accumulate("timeZone", details.getTimeZone());
                json.accumulate("tmpPassword", JSONObject.NULL);
                json.accumulate("traineeProjectCount", JSONObject.NULL);
                json.accumulate("type", details.getType());
                json.accumulate("userAccessLocation", JSONObject.NULL);
                json.accumulate("userId", JSONObject.NULL);
                json.accumulate("veteranBranch", JSONObject.NULL);
                json.accumulate("veteranClearance", JSONObject.NULL);
                json.accumulate("workAuthorization", JSONObject.NULL);
                if(zip_Code!=null && zip_Code!="null")
                json.accumulate("zip", details.getZip());
                else
                    json.accumulate("zip", JSONObject.NULL);

                json.accumulate("showProfilePicOnPublicProfile", "false");
                if(json_country.has("id"))
                json.accumulate("country",json_country);
                else
                    json.accumulate("country",JSONObject.NULL);

                json.accumulate("degrees", json_degree);
                json.accumulate("university", json_univ);
                json.accumulate("major", json_major);

                String jsonString = json.toString();
                StringEntity entity = new StringEntity(jsonString);
                System.out.println("data" + jsonString);
                put.setEntity(entity);
                HttpClient client = new DefaultHttpClient();
                HttpResponse response = client.execute(put);

                inputStream = response.getEntity().getContent();


                if (inputStream != null) {
                    result = convertInputStreamToString(inputStream);
                } else
                    result = "Did not work!";
                return null;

            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }
    }


}
