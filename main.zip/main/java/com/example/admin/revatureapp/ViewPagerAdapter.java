package com.example.admin.revatureapp;

/**
 * Created by home on 3/16/2018.
 */

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Parcelable;
import android.support.annotation.Nullable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.SparseArray;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;

public class ViewPagerAdapter extends PagerAdapter {
    LayoutInflater inflater;
    Context context;
    JSONArray array;
    String internassId,token;
    String assId,quizDuration;
    int time=0;
    Button button;
    TextView q1, q2, q3, q4,q5, textview;
    CheckBox q1option1, q1option2, q1option3, q1option4;
    RadioButton q2option1, q2option2, q3option1, q3option2, q3option3, q3option4;
    String questionType, question1;
    String[] options = new String[10];
    RelativeLayout relativeLayout, relativeLayout1, relativeLayout2,relativeLayout3,relativeLayout4;
    RadioGroup trueradio, radioGroup;
    String trueValue, radioValue;
    JSONArray assessmentQues = new JSONArray();
    JSONArray assessmentAnswers = new JSONArray();
    ArrayList<Integer> AnsweredQuestions = new ArrayList<>();
    JSONArray answers = new JSONArray();
    JSONArray payload = new JSONArray();
    Login login;
    Button buttonSave,buttonSubmit;
    EditText ans,shortAns;
    InputStream inputStream = null;
    String assessmentid, internId;
    ArrayList<JSONObject> checkedAnswers = new ArrayList<>();
    JSONObject json;
    private CountDownTimer countDownTimer;
    Long seconds;
    TextView timer;
    Quiz quiz;
    JSONObject LoginJson;
    String title;
    public ViewPagerAdapter() {

    }
    public ViewPagerAdapter(CountDownTimer countDownTimer) {
this.countDownTimer=countDownTimer;
    }

    public ViewPagerAdapter(Context context, JSONArray array, String internassId, String assId, Login login,String duration,JSONObject json,JSONObject LoginJson,String title) {
        this.context = context;
        this.array = array;
        this.internassId = internassId;
        this.assessmentid = assId;
        this.title=title;
this.json=json;
this.quizDuration=duration;
seconds=Long.parseLong(quizDuration);
this.LoginJson=LoginJson;
System.out.println("LoginJson"+LoginJson);
        this.login = login;
        this.token=this.login.getToken();
    }



    private static String convertInputStreamToString(InputStream inputStream) throws IOException {
        BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
        String line = "";
        StringBuilder result = new StringBuilder();
        while ((line = bufferedReader.readLine()) != null)
            result.append(line);

        inputStream.close();
        System.out.println("InputStream:" + result.toString());

        return result.toString();
    }

    @Override
    public int getCount() {
        return array.length();
    }

    @Override
    public boolean isViewFromObject(View view, Object object) {
        return view == ((RelativeLayout) object);
    }

    @Nullable
    @Override
    public Parcelable saveState() {



        return super.saveState();
    }

    @Override
    public void restoreState(@Nullable Parcelable state, @Nullable ClassLoader loader) {
        super.restoreState(state, loader);

    }

    @Override
    public Object instantiateItem(ViewGroup container, final int position) {



        inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        final View itemView = inflater.inflate(R.layout.viewpager_item, container,
                false);

        SavingViewStateViewPager save = new SavingViewStateViewPager(context);
        save.restoreViewState(position,itemView);

        relativeLayout = (RelativeLayout) itemView.findViewById(R.id.q2relativeLayout2);
        relativeLayout1 = (RelativeLayout) itemView.findViewById(R.id.q1relativeLayout);
        relativeLayout2 = (RelativeLayout) itemView.findViewById(R.id.q3relativeLayout);
        relativeLayout3 = (RelativeLayout) itemView.findViewById(R.id.q4relativeLayout);
        relativeLayout4 = (RelativeLayout) itemView.findViewById(R.id.q5relativeLayout);
        textview = (TextView) itemView.findViewById(R.id.textView3);
        q1 = (TextView) itemView.findViewById(R.id.q1);
        q2 = (TextView) itemView.findViewById(R.id.q2);
        q3 = (TextView) itemView.findViewById(R.id.q3);
        q4 = (TextView) itemView.findViewById(R.id.q4);
        q5 = (TextView) itemView.findViewById(R.id.q5);
        q1option1 = (CheckBox) itemView.findViewById(R.id.q1option1);
        q1option2 = (CheckBox) itemView.findViewById(R.id.q1option2);
        q1option3 = (CheckBox) itemView.findViewById(R.id.q1option3);
        q1option4 = (CheckBox) itemView.findViewById(R.id.q1option4);
        q2option1 = (RadioButton) itemView.findViewById(R.id.q2option1);
        q2option2 = (RadioButton) itemView.findViewById(R.id.q2option2);
        q3option1 = (RadioButton) itemView.findViewById(R.id.q3option1);
        q3option2 = (RadioButton) itemView.findViewById(R.id.q3option2);
        q3option3 = (RadioButton) itemView.findViewById(R.id.q3option3);
        q3option4 = (RadioButton) itemView.findViewById(R.id.q3option4);
        trueradio = (RadioGroup) itemView.findViewById(R.id.trueradio);
        radioGroup = (RadioGroup) itemView.findViewById(R.id.radio);
        ans=(EditText)itemView.findViewById(R.id.editText2);
        shortAns=(EditText)itemView.findViewById(R.id.editText3);
        buttonSave = (Button) itemView.findViewById(R.id.save);
        buttonSubmit = (Button) itemView.findViewById(R.id.submit);

                buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveMethod();
            }
        });
        buttonSubmit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                submitMethod();
            }
        });
         //startCountDownTimer(seconds*1000,1);

        // Locate the TextViews in viewpager_item.xml
        try {

            JSONObject ques = array.getJSONObject(position);
            int pos = position + 1;
            String qno =  pos +" "+ "-"+" " + array.length();
            textview.setText(qno);
            JSONObject question = ques.getJSONObject("question");
             time=Integer.parseInt(question.getString("duration"))+time;
            assessmentQues.put(position, question);
            final JSONArray answer = ques.getJSONArray("answers");
            assessmentAnswers.put(position, answer);

            questionType = question.getString("qsnType");

            if (questionType.equals("True or False")) {
                relativeLayout.setVisibility(View.VISIBLE);
                relativeLayout1.setVisibility(View.INVISIBLE);
                relativeLayout2.setVisibility(View.INVISIBLE);
                relativeLayout3.setVisibility(View.INVISIBLE);
                relativeLayout4.setVisibility(View.INVISIBLE);
                question1 = question.getString("title");
                q2.setText(question1);
                RadioButton[] radiosTrueFalse = {q2option1, q2option2};
                for (int k = 0; k < answer.length(); k++) {
                    JSONObject ans = answer.getJSONObject(k);
                    System.out.println("ANS" + k + ans.toString());
                    options[k] = ans.getString("answer");
                    String savedAns = ans.getString("answer");
                    radiosTrueFalse[k].setText(options[k]);
                    if(ans.has("isAnswered"))
                    {
                        radiosTrueFalse[k].setChecked(true);
                        try {
                            JSONArray options = assessmentAnswers.getJSONArray(position);
                            for (int k1 = 0; k1 < options.length(); k1++) {
                                JSONObject saved = options.getJSONObject(k1);
                                if (savedAns.equals(saved.getString("answer"))) {
                                    answers.put(position, saved);
                                    AnsweredQuestions.add(position);
                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }

                    }
                }

            } else if (questionType.equals("Multiple Choice")) {
                relativeLayout1.setVisibility(View.VISIBLE);
                relativeLayout.setVisibility(View.INVISIBLE);
                relativeLayout2.setVisibility(View.INVISIBLE);
                relativeLayout3.setVisibility(View.INVISIBLE);
                relativeLayout4.setVisibility(View.INVISIBLE);

                question1 = question.getString("title");
                q1.setText(question1);
                CheckBox[] option = {q1option1, q1option2, q1option3, q1option4};
                if(answer.length()<option.length)
                {
                    int num=option.length-answer.length();
                    if(num==1)
                    {
                        q1option4.setVisibility(View.INVISIBLE);
                    }else if(num==2)
                    {
                        q1option4.setVisibility(View.INVISIBLE);
                        q1option3.setVisibility(View.INVISIBLE);

                    }
                }
                for (int k = 0; k < answer.length(); k++) {
                    JSONObject ans = answer.getJSONObject(k);
                    System.out.println("ANS" + k + ans.toString());
                    options[k] = ans.getString("answer");
                    option[k].setText(options[k]);
                    if(ans.has("isAnswered"))
                    {
                        option[k].setChecked(true);
                        try {
                            JSONArray options = assessmentAnswers.getJSONArray(position);
                            System.out.println("opt" + options.toString());

                            JSONObject savedAns = options.getJSONObject(k);
                            System.out.println("selec" + ans.toString());


                            checkedAnswers.add(savedAns);
                            System.out.println("checked" + checkedAnswers);
                            answers.put(position, checkedAnswers);
                            AnsweredQuestions.add(position);


                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }

            } else if (questionType.equals("Best Choice")) {
                relativeLayout2.setVisibility(View.VISIBLE);
                relativeLayout.setVisibility(View.INVISIBLE);
                relativeLayout1.setVisibility(View.INVISIBLE);
                relativeLayout3.setVisibility(View.INVISIBLE);
                relativeLayout4.setVisibility(View.INVISIBLE);

                question1 = question.getString("title");
                q3.setText(question1);
                RadioButton[] radios = {q3option1, q3option2, q3option3, q3option4};
                if(answer.length()<radios.length)
                {
                    int num=radios.length-answer.length();
                    if(num==1)
                    {
                        q3option4.setVisibility(View.INVISIBLE);
                    }else if(num==2)
                    {
                        q3option4.setVisibility(View.INVISIBLE);
                        q3option3.setVisibility(View.INVISIBLE);

                    }
                }
                for (int k = 0; k < answer.length(); k++) {
                    JSONObject ans = answer.getJSONObject(k);
                    System.out.println("ANS" + k + ans.toString());
                    options[k] = ans.getString("answer");
                    String savedAns = ans.getString("answer");
                    radios[k].setText(options[k]);
                    if(ans.has("isAnswered"))
                    {
                        radios[k].setChecked(true);
                        try {
                            JSONArray options = assessmentAnswers.getJSONArray(position);
                            for (int k2 = 0; k2 < options.length(); k2++) {
                                JSONObject saved = options.getJSONObject(k2);
                                if (savedAns.equals(saved.getString("answer"))) {
                                    answers.put(position, saved);
                                    AnsweredQuestions.add(position);

                                }
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }

            } else if(questionType.equals("Numerical Value"))
            {
                relativeLayout2.setVisibility(View.INVISIBLE);
                relativeLayout.setVisibility(View.INVISIBLE);
                relativeLayout1.setVisibility(View.INVISIBLE);
                relativeLayout3.setVisibility(View.VISIBLE);
                relativeLayout4.setVisibility(View.INVISIBLE);

                question1=question.getString("title");
                q4.setText(question1);
                int k = 0;
                try {
                    JSONObject json = answer.getJSONObject(k);
                    if(json.has("isAnswered"))
                    {
                        String answer1=json.getString("oldAnswer");
                        ans.setText(answer1);
                        try {
                            JSONObject obj = new JSONObject();
                            obj.accumulate("answer", answer1);
                            answers.put(position, obj);
                            AnsweredQuestions.add(position);

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }}catch(Exception e)
                {
                    e.printStackTrace();
                }
                ans.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {

                            String answ = s.toString();
                            System.out.println("sa" + answ);
                            try {
                                JSONObject obj = new JSONObject();
                                obj.accumulate("answer", answ);
                                answers.put(position, obj);
                                AnsweredQuestions.add(position);

                            } catch (Exception e) {
                                e.printStackTrace();
                            }

                    }


                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });

            }else if(questionType.equals("Short Answer"))
            {
                relativeLayout2.setVisibility(View.INVISIBLE);
                relativeLayout.setVisibility(View.INVISIBLE);
                relativeLayout1.setVisibility(View.INVISIBLE);
                relativeLayout3.setVisibility(View.INVISIBLE);
                relativeLayout4.setVisibility(View.VISIBLE);
                question1=question.getString("title");
                q5.setText(question1);
                int k = 0;
                try {
                    JSONObject json = answer.getJSONObject(k);
                    if (json.has("isAnswered")) {
                        String answer1 = json.getString("oldAnswer");
                        shortAns.setText(answer1);
                        try {
                            JSONObject obj = new JSONObject();
                            obj.accumulate("answer", answer1);
                            answers.put(position, obj);
                            AnsweredQuestions.add(position);

                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }} catch (Exception e) {
                    e.printStackTrace();
                }
                shortAns.addTextChangedListener(new TextWatcher() {
                    @Override
                    public void beforeTextChanged(CharSequence s, int start, int count, int after) {

                    }

                    @Override
                    public void onTextChanged(CharSequence s, int start, int before, int count) {


                            String answ = s.toString();
                            System.out.println("sa" + answ);
                            try {
                                JSONObject obj = new JSONObject();
                                obj.accumulate("answer", answ);
                                answers.put(position, obj);
                                AnsweredQuestions.add(position);

                            } catch (Exception e) {
                                e.printStackTrace();
                            }


                    }
                    @Override
                    public void afterTextChanged(Editable s) {

                    }
                });





                }



        } catch (Exception e) {
            e.printStackTrace();
        }



        // Add viewpager_item.xml to ViewPager
        q1option1.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    try {
                        JSONArray options = assessmentAnswers.getJSONArray(position);
                        System.out.println("opt" + options.toString());

                        JSONObject ans = options.getJSONObject(0);
                        System.out.println("selec" + ans.toString());


                        checkedAnswers.add(ans);
                        System.out.println("checked" + checkedAnswers);
                        answers.put(position, checkedAnswers);
                        if(!(AnsweredQuestions.contains(position)))

                            AnsweredQuestions.add(position);



                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
                else
                {
                    try
                    {
                        JSONArray options = assessmentAnswers.getJSONArray(position);
                    JSONObject ans = options.getJSONObject(0);
                    checkedAnswers.remove(checkedAnswers.remove(ans));
                    AnsweredQuestions.remove(position);
                    }catch(Exception e)
                    {
                        e.printStackTrace();
                    }
                }
            }
        });

        q1option2.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    try {
                        JSONArray options = assessmentAnswers.getJSONArray(position);
                        JSONObject ans = options.getJSONObject(1);

                        checkedAnswers.add(ans);
                        System.out.println("checked" + checkedAnswers);

                        answers.put(position, checkedAnswers);
                        if(!(AnsweredQuestions.contains(position)))
                        AnsweredQuestions.add(position);

                        System.out.println("checkedans" + answers.toString());

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }

                    else
                    {
                        try
                        {
                            JSONArray options = assessmentAnswers.getJSONArray(position);
                            JSONObject ans = options.getJSONObject(1);
                            checkedAnswers.remove(checkedAnswers.remove(ans));
                            AnsweredQuestions.remove(position);

                        }catch(Exception e)
                        {
                            e.printStackTrace();
                        }
                    }

            }

        });
        q1option3.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked){
                    try {
                        JSONArray options = assessmentAnswers.getJSONArray(position);
                        JSONObject ans = options.getJSONObject(2);

                        checkedAnswers.add(ans);
                        answers.put(position, checkedAnswers);
                        if(!(AnsweredQuestions.contains(position)))

                            AnsweredQuestions.add(position);


                    } catch (Exception e) {
                        e.printStackTrace();
                    }
            }
                else
                {
                    try
                    {
                        JSONArray options = assessmentAnswers.getJSONArray(position);
                        JSONObject ans = options.getJSONObject(2);
                        checkedAnswers.remove(checkedAnswers.remove(ans));
                        AnsweredQuestions.remove(position);

                    }catch(Exception e)
                    {
                        e.printStackTrace();
                    }
                }
            }
        });
        q1option4.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    try {
                        JSONArray options = assessmentAnswers.getJSONArray(position);
                        JSONObject ans = options.getJSONObject(3);

                        checkedAnswers.add(ans);
                        answers.put(position, checkedAnswers);
                        if(!(AnsweredQuestions.contains(position)))

                            AnsweredQuestions.add(position);



                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
                else
                {
                    try
                    {
                        JSONArray options = assessmentAnswers.getJSONArray(position);
                        JSONObject ans = options.getJSONObject(3);
                        checkedAnswers.remove(checkedAnswers.remove(ans));
                        AnsweredQuestions.remove(position);

                    }catch(Exception e)
                    {
                        e.printStackTrace();
                    }
                }

            }
        });
        trueradio.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton selected = itemView.findViewById(checkedId);
                System.out.println("RADIOid:" + checkedId);
                trueValue = selected.getText().toString();
                System.out.println("selected" + trueValue);
                try {
                    JSONArray options = assessmentAnswers.getJSONArray(position);
                    for (int k = 0; k < options.length(); k++) {
                        JSONObject ans = options.getJSONObject(k);
                        if (trueValue.equals(ans.getString("answer"))) {
                            answers.put(position, ans);

                            AnsweredQuestions.add(position);

                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }

            }
        });
        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                RadioButton selected = itemView.findViewById(checkedId);
                radioValue = selected.getText().toString();
                System.out.println("selected" + radioValue);
                try {
                    JSONArray options = assessmentAnswers.getJSONArray(position);
                    for (int k = 0; k < options.length(); k++) {
                        JSONObject ans = options.getJSONObject(k);
                        if (radioValue.equals(ans.getString("answer"))) {
                            answers.put(position, ans);
                            AnsweredQuestions.add(position);

                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        ((ViewPager) container).addView(itemView);
        return itemView;
    }

    @Override
    public void destroyItem(ViewGroup container, int position, Object object) {
     //   stopCountDownTimer();
        // Remove viewpager_item.xml from ViewPager

        SavingViewStateViewPager save = new SavingViewStateViewPager(context);
        save.saveViewState(position,container);
        ((ViewPager) container).removeView((RelativeLayout) object);

    }

    public void saveMethod() {
        AlertDialog.Builder alertDialog = new AlertDialog.Builder(context).setIcon(R.drawable.ic_submission).setTitle("Quiz Save Confirmation");
        alertDialog.setMessage("Saving will exit the quiz.You may resume it from Dashboard");
        alertDialog.setPositiveButton("Continue", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                new save().execute();
            }
        });
        alertDialog.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //if user select "No", just cancel this dialog and continue with app
                dialog.cancel();
            }
        });
        AlertDialog alert = alertDialog.create();
        alert.show();

    }
    public void submitMethod() {

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(context).setIcon(R.drawable.ic_submission).setTitle("Quiz Submission Confirmation");
        alertDialog.setMessage("This will end your quiz attempt and submit the quiz.Are you sure?");
        alertDialog.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                new submit().execute();
            }
        });
        alertDialog.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //if user select "No", just cancel this dialog and continue with app
                dialog.cancel();
            }
        });
        AlertDialog alert = alertDialog.create();
        alert.show();

    }

    class save extends AsyncTask<String, String, String> {
        String id, answerId,totalTime, isCorrect, ansIsSticky, isSticky, ansOrder, order, poolId, qsnType,  result,timeSpent;
        JSONArray answer;
        JSONObject question;
        JSONObject object;
        String[] spentTime= new String[3];
        JSONArray assessmentQuestions = new JSONArray();
        Quiz quiz= new Quiz();
        int l=0;

        @Override
        protected String doInBackground(String... strings) {

totalTime= Quiz.quizDuration;
            timeSpent=quiz.timer();
            spentTime=timeSpent.split(":");
          int time=Integer.parseInt(spentTime[0])*3600+Integer.parseInt(spentTime[1])*60+Integer.parseInt(spentTime[2]);
            timeSpent=Integer.toString(Integer.parseInt(totalTime)-time);
          for (int k1 = 0; k1 <= AnsweredQuestions.size() - 1; k1++) {
                   int i=AnsweredQuestions.get(k1);
                   System.out.println("i"+i);
                try {

                    System.out.println("ID" + assessmentid);
                    JSONObject json1 = assessmentQues.getJSONObject(i);
                    System.out.println("q" + json1.toString());
                    id = assessmentQues.getJSONObject(i).getString("id");
                    isSticky = assessmentQues.getJSONObject(i).getString("isSticky");
                    if (assessmentQues.getJSONObject(i).has("order"))
                        order = assessmentQues.getJSONObject(i).getString("order");
                    poolId = assessmentQues.getJSONObject(i).getString("poolId");
                    qsnType = assessmentQues.getJSONObject(i).getString("qsnType");
                    question = new JSONObject();
                    question.accumulate("id", id);
                    question.accumulate("isCorrect", "N");
                    question.accumulate("isSticky", isSticky);
                    question.accumulate("order", order);
                    question.accumulate("poolId", poolId);
                    question.accumulate("qsnType", qsnType);
                    if (qsnType.equals("Multiple Choice")) {
                        for (int j = i; j <= i; j++) {

                            Object object = answers.get(j);
                            if (object != null) {
                                answer = new JSONArray();

                                ArrayList array = (ArrayList) object;
                                for (int k = 0; k < array.size(); k++) {
                                    JSONObject jsonObject = (JSONObject) array.get(k);
                                    answerId = jsonObject.getString("id");
                                    ansIsSticky = jsonObject.getString("isSticky");
                                    ansOrder = jsonObject.getString("order");
                                    JSONObject obj = new JSONObject();
                                    obj.accumulate("id", answerId);
                                    obj.accumulate("isSticky", ansIsSticky);
                                    obj.accumulate("order", ansOrder);
                                    answer.put(k, obj);
                                }
                            }
                        }
                    } else if (qsnType.equals("Best Choice")) {
                        for (int j = i; j <= i; j++) {
                            int k = 0;

                            if (answers.getJSONObject(j) != null) {
                                answerId = answers.getJSONObject(j).getString("id");
                                ansIsSticky = answers.getJSONObject(j).getString("isSticky");
                                ansOrder = answers.getJSONObject(j).getString("order");
                                answer = new JSONArray();
                                JSONObject obj = new JSONObject();
                                obj.accumulate("id", answerId);
                                obj.accumulate("isSticky", ansIsSticky);
                                obj.accumulate("order", ansOrder);
                                answer.put(k, obj);

                            }
                        }
                    } else if (qsnType.equals("True or False")) {
                        for (int j = i; j <= i; j++) {
                            int k = 0;

                            if (answers.getJSONObject(j) != null) {
                                answerId = answers.getJSONObject(j).getString("id");
                                ansIsSticky = answers.getJSONObject(j).getString("isSticky");
                                ansOrder = answers.getJSONObject(j).getString("order");
                                answer = new JSONArray();
                                JSONObject obj = new JSONObject();
                                obj.accumulate("id", answerId);
                                obj.accumulate("isSticky", ansIsSticky);
                                obj.accumulate("order", ansOrder);
                                answer.put(k, obj);

                            }
                        }
                    } else if (qsnType.equals("Numerical Value")) {
                        int k = 0;
                        String ans = answers.getJSONObject(i).getString("answer");
                        JSONObject obj = new JSONObject();
                        obj.accumulate("answer", ans);
                        answer = new JSONArray();
                        answer.put(k, obj);
                    } else if (qsnType.equals("Short Answer")) {
                        int k = 0;
                        String ans = answers.getJSONObject(i).getString("answer");
                        JSONObject obj = new JSONObject();
                        obj.accumulate("answer", ans);
                        answer = new JSONArray();
                        answer.put(k, obj);
                    }

                    System.out.println("Q" + question);
                    System.out.println("A" + answer);
                    JSONObject json = new JSONObject();
                    json.accumulate("question", question);
                    json.accumulate("answers", answer);
                    assessmentQuestions.put(l++, json);


                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
            System.out.println("assmtid" + assessmentid);
            System.out.println("assmtid" + internassId);
            try {
                object = new JSONObject();
                object.accumulate("assessmentQuestions", assessmentQuestions);
                object.accumulate("timeSpent", timeSpent);
                object.accumulate("assmtId", assessmentid);
                object.accumulate("internAssmtId", internassId);
            } catch (Exception e) {
                e.printStackTrace();
            }
          token=login.getToken();
            try {
                HttpPost post = new HttpPost("https://qa2.revature.com/core/resources/secure/quiz/save/1?saveType=quiz&assignedBatchActId=0");
                post.setHeader("Accept", "application/json");
                post.setHeader("Content-type", "application/json");
                post.setHeader("Authorization", token);
                System.out.println("PAYLOAD" + object.toString());
                StringEntity entity = new StringEntity(object.toString());
                post.setEntity(entity);
                HttpClient httpclient = new DefaultHttpClient();

                HttpResponse res = httpclient.execute(post);

                inputStream = res.getEntity().getContent();


                if (inputStream != null) {
                    result = convertInputStreamToString(inputStream);
                } else {
                    result = "Did not work!";
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
            return null;
        }


        @Override
        protected void onPostExecute(String s) {
            try {
                JSONObject myObject = new JSONObject(result);
                String statusCode = myObject.getString("statusCode");
                String description = myObject.getString("description");

                if (statusCode.equals("SC003")) {

                    Intent intent = new Intent(context, SaveActivity.class);
                    intent.putExtra("Login",login);
                    intent.putExtra("json",json.toString());
                    intent.putExtra("json1",LoginJson.toString());
                    intent.putExtra("title",title);

                    context.startActivity(intent);
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void submitMethod1(Context context)
    {
        this.context=context;
        new submit().execute();
    }

        class submit extends AsyncTask<String, String, String> {
            String id, answerId,timeSpent, isCorrect, ansIsSticky, isSticky, ansOrder, order, poolId, qsnType, token, result,totalTime;
            JSONArray answer;
            JSONObject question;
            String[] spentTime= new String[3];
            JSONObject object;
            JSONArray assessmentQuestions = new JSONArray();
int l=0;        Quiz quiz= new Quiz();

            @Override
            protected void onPostExecute(String s) {
                try {
                    JSONObject myObject = new JSONObject(result);
                    JSONObject obj= myObject.getJSONObject("data");
                    String statusCode = myObject.getString("statusCode");
                    String percentage = obj.getString("internPercent");
                    String pass=obj.getString("isPassed");
                    String description = myObject.getString("description");
                    if (statusCode.equals("SC003")) {
                        Intent intent = new Intent(context, SubmitActivity.class);
                        intent.putExtra("per",percentage);
                        intent.putExtra("passper",pass);
                        intent.putExtra("Login",login);
                        intent.putExtra("json1",LoginJson.toString());
                        intent.putExtra("title",title);
                        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        context.startActivity(intent);

                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
                @Override
                protected String doInBackground (String...strings){
                    totalTime= Quiz.quizDuration;
                    timeSpent=quiz.timer();
                    spentTime=timeSpent.split(":");
                    int time=Integer.parseInt(spentTime[0])*3600+Integer.parseInt(spentTime[1])*60+Integer.parseInt(spentTime[2]);
                    timeSpent=Integer.toString(Integer.parseInt(totalTime)-time);

                    for (int k1 = 0; k1 <= AnsweredQuestions.size() - 1; k1++) {
                        int i=AnsweredQuestions.get(k1);

                        try {

                            System.out.println("ID" + assessmentid);
                            JSONObject json1 = assessmentQues.getJSONObject(i);
                            System.out.println("q" + json1.toString());
                            id = assessmentQues.getJSONObject(i).getString("id");
                            isSticky = assessmentQues.getJSONObject(i).getString("isSticky");
                            if (assessmentQues.getJSONObject(i).has("order"))
                                order = assessmentQues.getJSONObject(i).getString("order");
                            poolId = assessmentQues.getJSONObject(i).getString("poolId");
                            qsnType = assessmentQues.getJSONObject(i).getString("qsnType");
                            question = new JSONObject();
                            question.accumulate("id", id);
                            question.accumulate("isCorrect", "N");
                            question.accumulate("isSticky", isSticky);
                            question.accumulate("order", order);
                            question.accumulate("poolId", poolId);
                            question.accumulate("qsnType", qsnType);
                            if (qsnType.equals("Multiple Choice")) {
                                for (int j = i; j <= i; j++) {

                                    Object object = answers.get(j);
                                    if (object != null) {
                                        answer = new JSONArray();

                                        ArrayList array = (ArrayList) object;
                                        for (int k = 0; k < array.size(); k++) {
                                            JSONObject jsonObject = (JSONObject) array.get(k);
                                            answerId = jsonObject.getString("id");
                                            ansIsSticky = jsonObject.getString("isSticky");
                                            ansOrder = jsonObject.getString("order");
                                            JSONObject obj = new JSONObject();
                                            obj.accumulate("id", answerId);
                                            obj.accumulate("isSticky", ansIsSticky);
                                            obj.accumulate("order", ansOrder);
                                            answer.put(k, obj);
                                        }
                                    }
                                }
                            } else if (qsnType.equals("Best Choice")) {
                                for (int j = i; j <= i; j++) {
                                    int k = 0;
                                    if (answers.getJSONObject(j) != null) {
                                        answerId = answers.getJSONObject(j).getString("id");
                                        ansIsSticky = answers.getJSONObject(j).getString("isSticky");
                                        ansOrder = answers.getJSONObject(j).getString("order");
                                        answer = new JSONArray();
                                        JSONObject obj = new JSONObject();
                                        obj.accumulate("id", answerId);
                                        obj.accumulate("isSticky", ansIsSticky);
                                        obj.accumulate("order", ansOrder);
                                        answer.put(k, obj);

                                    }
                                }
                            } else if (qsnType.equals("True or False")) {
                                for (int j = i; j <= i; j++) {
                                    int k = 0;
                                    if (answers.getJSONObject(j) != null) {
                                        answerId = answers.getJSONObject(j).getString("id");
                                        ansIsSticky = answers.getJSONObject(j).getString("isSticky");
                                        ansOrder = answers.getJSONObject(j).getString("order");
                                        answer = new JSONArray();
                                        JSONObject obj = new JSONObject();
                                        obj.accumulate("id", answerId);
                                        obj.accumulate("isSticky", ansIsSticky);
                                        obj.accumulate("order", ansOrder);
                                        answer.put(k, obj);

                                    }
                                }
                            } else if (qsnType.equals("Numerical Value")) {
                                int k = 0;
                                String ans = answers.getJSONObject(i).getString("answer");
                                JSONObject obj = new JSONObject();
                                obj.accumulate("answer", ans);
                                answer = new JSONArray();
                                answer.put(k, obj);
                            } else if (qsnType.equals("Short Answer")) {
                                int k = 0;
                                String ans = answers.getJSONObject(i).getString("answer");
                                JSONObject obj = new JSONObject();
                                obj.accumulate("answer", ans);
                                answer = new JSONArray();
                                answer.put(k, obj);
                            }
                            System.out.println("Q" + question);
                            System.out.println("A" + answer);
                            JSONObject json = new JSONObject();
                            json.accumulate("question", question);
                            json.accumulate("answers", answer);
                            assessmentQuestions.put(l++, json);


                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    System.out.println("assmtid" + assessmentid);
                    System.out.println("assmtid" + internassId);
                    try {
                        object = new JSONObject();
                        object.accumulate("assessmentQuestions", assessmentQuestions);
                        object.accumulate("timeSpent", timeSpent);
                        object.accumulate("assmtId", assessmentid);
                        object.accumulate("internAssmtId", internassId);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                   token=DashboardActivity.getDefaults("token",context);

                    try {
                        HttpPost post = new HttpPost("https://qa2.revature.com/core/resources/secure/quiz/save/0?saveType=quiz&assignedBatchActId=0");
                        post.setHeader("Accept", "application/json");
                        post.setHeader("Content-type", "application/json");
                        post.setHeader("Authorization", token);
                        System.out.println("PAYLOAD" + object.toString());
                        StringEntity entity = new StringEntity(object.toString());
                        post.setEntity(entity);
                        HttpClient httpclient = new DefaultHttpClient();

                        HttpResponse res = httpclient.execute(post);

                        inputStream = res.getEntity().getContent();


                        if (inputStream != null) {
                            result = convertInputStreamToString(inputStream);
                        } else {
                            result = "Did not work!";
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    return null;
                }
            }

        }


