package com.example.admin.revatureapp;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.ArrayList;


public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    private ArrayList<MyActivityModel> myactivitytmodel;
    private Login login;
    RecyclerView recyclerView;
    Context context;
    JSONObject json;

    public CustomAdapter(Context context, ArrayList<MyActivityModel> myactivitytmodel,RecyclerView recyclerview,Login login,JSONObject json) {
        this.context = context;
        this.myactivitytmodel=myactivitytmodel;
        this.recyclerView=recyclerview;
        this.login=login;
        this.json=json;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        // infalte the item Layout
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.horizontalrowlayout, parent, false);
        // set the view's size, margins, paddings and layout parameters
        MyViewHolder vh = new MyViewHolder(v); // pass the view to View Holder
        return vh;
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {
        // set the data in items
        holder.categoryType.setText(myactivitytmodel.get(position).getCategoryName());
        // implement setOnClickListener event on item view.
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // display a toast with person name on item click
             String name=myactivitytmodel.get(position).getCategoryName();
             if(name!=null)
             filter(name);

            }
        });

    }
    private void filter(String text) {
        //new array list that will hold the filtered data
        ArrayList<MyActivityModel> filterdNames = new ArrayList<>();

        //looping through existing elements
        for (MyActivityModel s : myactivitytmodel) {
            //if the existing elements contains the search input
               if (s.getCategory().contains(text)) {
                //adding the element to filtered list
                filterdNames.add(s);
            }
        }
        System.out.println("Filtered" + filterdNames);

        //calling a method of the adapter class and passing the filtered list
        DataAdapter adapter = new DataAdapter(filterdNames,login,json);
        recyclerView.setAdapter(adapter);
    }

    @Override
    public int getItemCount() {
        int a;
        if(myactivitytmodel!=null&&!myactivitytmodel.isEmpty())
        {
            a=myactivitytmodel.size();
        }
        else {
            a=0;
        }
        return a;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {
        // init the item view's
        TextView categoryType;


        public MyViewHolder(View itemView) {
            super(itemView);

            // get the reference of item view's
            categoryType = (TextView) itemView.findViewById(R.id.categoryType);


        }
    }
}
