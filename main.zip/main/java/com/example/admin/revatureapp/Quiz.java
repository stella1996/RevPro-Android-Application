package com.example.admin.revatureapp;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.CountDownTimer;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

public class Quiz extends AppCompatActivity {
    ViewPager viewPager;
    public static CountDownTimer countDownTimer=null;
    ViewPagerAdapter adapter;
    Button buttonSave,buttonSubmit;
    JSONArray array,data;
    TextView q1, q2, q3, q4;
    CheckBox q1option1, q1option2, q1option3, q1option4;
    RadioButton q2option1, q2option2, q3option1, q3option2, q3option3, q3option4;
    JSONObject json,LoginJson;
    String questionType, question1,id;
JSONArray array1,array2;
    String[] options = new String[10];
    String internId,timeSpent,status;
    static String assId,quizDuration ;
    String percentage="0";
    String pass="N";
Login login;
TextView timer;
 static  String currentTime;
 JSONArray listviewArray;
    private int savedImagePosition;
    RelativeLayout relativeLayout, relativeLayout1, relativeLayout2;
String title;
Context context;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.viewpager_main);
        context=getApplicationContext();
        Toolbar myToolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(myToolbar);
        login = (Login) getIntent().getSerializableExtra("Login");
id=getIntent().getStringExtra("id");
title=getIntent().getStringExtra("title");
buttonSubmit = (Button) findViewById(R.id.submit);
        buttonSave = (Button) findViewById(R.id.save);


        timer=(TextView)findViewById(R.id.timer);
timeSpent=getIntent().getStringExtra("timeSpent");
status=getIntent().getStringExtra("status");

        viewPager = (ViewPager) findViewById(R.id.pager);

        try
        {
            String json1=DashboardActivity.getDefaults("json",context);
          LoginJson = new JSONObject(json1);
            System.out.println(json.toString());


        }catch (Exception e)
        {
            e.printStackTrace();
        }
        try {
            json = new JSONObject(getIntent().getStringExtra("json"));
            System.out.println("json" + json.toString());
            data = json.getJSONArray("data");
            int length = data.length();
            for (int i = 0; i < length; i++) {
                JSONObject json1 = data.getJSONObject(i);
                array = json1.getJSONArray("questions");
                internId=json1.getString("internAssessmentId");
                quizDuration = json1.getString("quizDuration");
                System.out.println("timeSpent"+timeSpent);
                if(timeSpent!=null && status.equals("In-Progress"))
                {
                    System.out.println("time"+timeSpent);
                   String quizDura=Integer.toString(Integer.parseInt(quizDuration)-Integer.parseInt(timeSpent));
                    System.out.println("time"+quizDura);
                    int quizDuration1=Integer.parseInt(quizDura);
                    startCountDownTimer(quizDuration1*1000,1);

                }
                else{


                int quizDuration1=Integer.parseInt(quizDuration);
startCountDownTimer(quizDuration1*1000,1);}
                System.out.println("inid"+internId);

                assId=id;
                System.out.println("inid"+assId);

            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        // Pass results to ViewPagerAdapter Class
        adapter = new ViewPagerAdapter(Quiz.this, array,internId,assId,login,quizDuration,json,LoginJson,title);
        // Binds the Adapter to the ViewPager
        viewPager.setAdapter(adapter);
        viewPager.setOffscreenPageLimit(array.length());




    }

    private void startCountDownTimer(long duration, long interval){
        countDownTimer = new CountDownTimer(duration, interval) {
            @Override
            public void onTick(long millisUntilFinished) {
              long  seconds = millisUntilFinished/1000;//convert to seconds
                long minutes = seconds / 60;//convert to minutes
                long hours = minutes / 60;//convert to hours
                if(minutes > 0)//if we have minutes, then there might be some remainder seconds
                    seconds = seconds % 60;//seconds can be between 0-60, so we use the % operator to get the remainder
                if(hours > 0)
                    minutes = minutes % 60;//similar to seconds
                String time = formatNumber(hours) + ":" + formatNumber(minutes) + ":" +
                        formatNumber(seconds);
                System.out.println("timer"+time);
                timer.setText(time);
                currentTime =timer.getText().toString();

            }
            @Override
            public void onFinish() {
                adapter.submitMethod1(getApplicationContext());
            }

        };
        countDownTimer.start();

    }
    private String formatNumber(long value){
        if(value < 10)
            return "0" + value;
        return value + "";
    }

    @Override
    public void onBackPressed() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(false);
        builder.setMessage("Your answer will be unsaved.Are you sure you want to Exit?");
        builder.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                countDownTimer.cancel();
                Intent intent = new Intent(Quiz.this,DashboardActivity.class);
                intent.putExtra("Login_Class",login);
                intent.putExtra("JSON_RESPONSE",LoginJson.toString());
                startActivity(intent);
            }
        });
        builder.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                //if user select "No", just cancel this dialog and continue with app
                dialog.cancel();
            }
        });
        AlertDialog alert = builder.create();
        alert.show();
    }

public String timer()
{
    countDownTimer.cancel();
    System.out.println("cu"+currentTime);
    return currentTime;
}



}